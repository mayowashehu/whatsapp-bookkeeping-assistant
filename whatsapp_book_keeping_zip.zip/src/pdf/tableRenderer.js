/**
 * Reusable PDFKit table renderer with automatic pagination
 * and repeated headers on each new page.
 */

export function createTableRenderer(doc, options = {}) {
  const page = {
    marginLeft: options.marginLeft ?? 50,
    marginRight: options.marginRight ?? 50,
    marginBottom: options.marginBottom ?? 60,
    topAfterPageBreak: options.topAfterPageBreak ?? 50,
  };

  const width =
    options.tableWidth ?? doc.page.width - page.marginLeft - page.marginRight;

  /**
   * @param {{
   *   columns: Array<{ key: string, label: string, width: number, align?: 'left'|'right' }>,
   *   rows: Array<Record<string, string>>,
   *   startY: number,
   *   rowHeight?: number,
   *   headerHeight?: number,
   *   fontSize?: number,
   *   headerFontSize?: number,
   * }} config
   * @returns {number} Y position after the table
   */
  function renderTable(config) {
    const columns = config.columns || [];
    const rows = config.rows || [];
    const rowHeight = config.rowHeight ?? 18;
    const headerHeight = config.headerHeight ?? 20;
    const fontSize = config.fontSize ?? 9;
    const headerFontSize = config.headerFontSize ?? 9;

    let y = config.startY;

    const ensureSpace = (needed) => {
      if (y + needed <= doc.page.height - page.marginBottom) {
        return;
      }
      doc.addPage();
      y = page.topAfterPageBreak;
      drawHeader();
    };

    const drawHeader = () => {
      doc.save();
      doc.rect(page.marginLeft, y, width, headerHeight).fill('#F3F4F6');
      doc.fillColor('#111827').font('Helvetica-Bold').fontSize(headerFontSize);

      let x = page.marginLeft;
      for (const column of columns) {
        const textX = column.align === 'right' ? x + column.width - 4 : x + 4;
        doc.text(column.label, textX, y + 5, {
          width: column.width - 8,
          align: column.align === 'right' ? 'right' : 'left',
          lineBreak: false,
        });
        x += column.width;
      }

      y += headerHeight;
      doc
        .moveTo(page.marginLeft, y)
        .lineTo(page.marginLeft + width, y)
        .strokeColor('#D1D5DB')
        .lineWidth(0.5)
        .stroke();
      doc.restore();
      y += 4;
    };

    drawHeader();

    doc.font('Helvetica').fontSize(fontSize).fillColor('#111827');

    for (const row of rows) {
      ensureSpace(rowHeight + 2);

      let x = page.marginLeft;
      for (const column of columns) {
        const value = row[column.key] == null ? '' : String(row[column.key]);
        const textX = column.align === 'right' ? x + column.width - 4 : x + 4;
        doc.text(value, textX, y + 3, {
          width: column.width - 8,
          align: column.align === 'right' ? 'right' : 'left',
          lineBreak: false,
          ellipsis: false,
        });
        x += column.width;
      }

      y += rowHeight;
      doc
        .moveTo(page.marginLeft, y)
        .lineTo(page.marginLeft + width, y)
        .strokeColor('#E5E7EB')
        .lineWidth(0.4)
        .stroke();
    }

    return y + 8;
  }

  return {
    renderTable,
  };
}

export default {
  createTableRenderer,
};
