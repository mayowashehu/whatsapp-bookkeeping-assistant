import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import PDFDocument from 'pdfkit';
import { createTableRenderer } from './tableRenderer.js';

const MARGIN_LEFT = 50;
const MARGIN_RIGHT = 50;
const MARGIN_TOP = 48;
const MARGIN_BOTTOM = 56;

/**
 * Renders an already-formatted statement object to a PDF file.
 * Never calculates totals — values come from StatementFormatter.
 *
 * @param {object} statement Formatted statement from StatementFormatter
 * @returns {Promise<string>} Absolute pdfPath in os.tmpdir()
 */
export async function generateStatementPdf(statement) {
  const filename = `statement-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.pdf`;
  const pdfPath = path.join(os.tmpdir(), filename);

  const doc = new PDFDocument({
    size: 'A4',
    bufferPages: true,
    margins: {
      top: MARGIN_TOP,
      bottom: MARGIN_BOTTOM,
      left: MARGIN_LEFT,
      right: MARGIN_RIGHT,
    },
    info: {
      Title: `${statement.header.propertyName} — ${statement.header.reportingPeriod}`,
      Author: 'WhatsApp Bookkeeping Assistant',
      Creator: 'WhatsApp Bookkeeping Assistant v0.1',
    },
  });

  const stream = fs.createWriteStream(pdfPath);
  doc.pipe(stream);

  let y = MARGIN_TOP;
  y = renderHeader(doc, statement, y);
  y = renderFinancialSummary(doc, statement, y);
  y = renderExpenseBreakdown(doc, statement, y);
  renderTransactionTable(doc, statement, y);
  renderFooter(doc, statement);

  doc.end();

  try {
    await new Promise((resolve, reject) => {
      stream.on('finish', resolve);
      stream.on('error', reject);
      doc.on('error', reject);
    });
  } catch (err) {
    try {
      fs.unlinkSync(pdfPath);
    } catch {
      // ignore cleanup errors
    }
    throw err;
  }

  return pdfPath;
}

function contentWidth(doc) {
  return doc.page.width - MARGIN_LEFT - MARGIN_RIGHT;
}

function renderHeader(doc, statement, startY) {
  let y = startY;
  const header = statement.header;

  doc
    .fillColor('#111827')
    .font('Helvetica-Bold')
    .fontSize(18)
    .text(header.propertyName, MARGIN_LEFT, y, {
      width: contentWidth(doc),
      align: 'left',
    });
  y = doc.y + 8;

  doc
    .font('Helvetica')
    .fontSize(11)
    .fillColor('#374151')
    .text(`Reporting Period: ${header.reportingPeriod}`, MARGIN_LEFT, y);
  y = doc.y + 2;
  doc.text(`Currency: ${header.currency}`, MARGIN_LEFT, y);
  y = doc.y + 2;
  doc.text(`Date Generated: ${header.generatedAt}`, MARGIN_LEFT, y);
  y = doc.y + 14;

  doc
    .moveTo(MARGIN_LEFT, y)
    .lineTo(MARGIN_LEFT + contentWidth(doc), y)
    .strokeColor('#D1D5DB')
    .lineWidth(1)
    .stroke();

  return y + 16;
}

function renderFinancialSummary(doc, statement, startY) {
  let y = startY;
  const summary = statement.summary;

  doc
    .fillColor('#111827')
    .font('Helvetica-Bold')
    .fontSize(13)
    .text('Financial Summary', MARGIN_LEFT, y);
  y = doc.y + 10;

  const rows = [
    ['Total Income', summary.totalIncomeFormatted],
    ['Total Expenses', summary.totalExpensesFormatted],
    ['Net Amount', summary.netIncomeFormatted],
  ];

  const labelWidth = contentWidth(doc) * 0.55;
  const valueWidth = contentWidth(doc) * 0.45;

  for (const [label, value] of rows) {
    const isNet = label === 'Net Amount';
    doc
      .font(isNet ? 'Helvetica-Bold' : 'Helvetica')
      .fontSize(11)
      .fillColor('#111827')
      .text(label, MARGIN_LEFT, y, { width: labelWidth, align: 'left' });
    doc.text(value, MARGIN_LEFT + labelWidth, y, {
      width: valueWidth,
      align: 'right',
    });
    y += 18;
  }

  return y + 12;
}

function renderExpenseBreakdown(doc, statement, startY) {
  let y = startY;

  doc
    .fillColor('#111827')
    .font('Helvetica-Bold')
    .fontSize(13)
    .text('Expense Breakdown', MARGIN_LEFT, y);
  y = doc.y + 10;

  const breakdown = statement.expenseBreakdown || [];
  if (breakdown.length === 0) {
    doc
      .font('Helvetica')
      .fontSize(10)
      .fillColor('#6B7280')
      .text('No expenses in this period.', MARGIN_LEFT, y);
    return doc.y + 14;
  }

  const labelWidth = contentWidth(doc) * 0.55;
  const valueWidth = contentWidth(doc) * 0.45;

  doc.font('Helvetica').fontSize(10).fillColor('#111827');

  for (const row of breakdown) {
    const label = row.category;
    const value = row.totalFormatted;
    const labelTextWidth = doc.widthOfString(label);
    const availableDots = Math.max(
      3,
      Math.floor((labelWidth - labelTextWidth - 12) / Math.max(doc.widthOfString('.'), 1)),
    );
    const dottedLabel = `${label} ${'.'.repeat(availableDots)}`;

    doc.text(dottedLabel, MARGIN_LEFT, y, {
      width: labelWidth,
      align: 'left',
      lineBreak: false,
    });
    doc.text(value, MARGIN_LEFT + labelWidth, y, {
      width: valueWidth,
      align: 'right',
      lineBreak: false,
    });
    y += 16;
  }

  return y + 14;
}

function renderTransactionTable(doc, statement, startY) {
  let y = startY;

  doc
    .fillColor('#111827')
    .font('Helvetica-Bold')
    .fontSize(13)
    .text('Transactions', MARGIN_LEFT, y);
  y = doc.y + 10;

  const transactions = statement.transactions || [];
  if (transactions.length === 0) {
    doc
      .font('Helvetica')
      .fontSize(10)
      .fillColor('#6B7280')
      .text('No transactions in this period.', MARGIN_LEFT, y);
    return doc.y + 14;
  }

  const tableWidth = contentWidth(doc);
  const columns = [
    { key: 'date', label: 'Date', width: tableWidth * 0.16, align: 'left' },
    { key: 'type', label: 'Type', width: tableWidth * 0.14, align: 'left' },
    { key: 'category', label: 'Category', width: tableWidth * 0.18, align: 'left' },
    { key: 'description', label: 'Description', width: tableWidth * 0.32, align: 'left' },
    { key: 'amount', label: 'Amount', width: tableWidth * 0.2, align: 'right' },
  ];

  const rows = transactions.map((tx) => ({
    date: tx.date,
    type: tx.type,
    category: tx.category,
    description: tx.description || '—',
    amount: tx.amountFormatted,
  }));

  const table = createTableRenderer(doc, {
    marginLeft: MARGIN_LEFT,
    marginRight: MARGIN_RIGHT,
    marginBottom: MARGIN_BOTTOM + 24,
    topAfterPageBreak: MARGIN_TOP,
    tableWidth,
  });

  return table.renderTable({
    columns,
    rows,
    startY: y,
    rowHeight: 18,
    headerHeight: 20,
    fontSize: 9,
    headerFontSize: 9,
  });
}

function renderFooter(doc, statement) {
  const footerText = statement.footer?.text || 'Generated by WhatsApp Bookkeeping Assistant v0.1';
  const range = doc.bufferedPageRange();

  for (let i = 0; i < range.count; i += 1) {
    doc.switchToPage(range.start + i);
    const y = doc.page.height - 36;
    doc
      .font('Helvetica')
      .fontSize(8)
      .fillColor('#6B7280')
      .text(footerText, MARGIN_LEFT, y, {
        width: contentWidth(doc) - 60,
        align: 'left',
        lineBreak: false,
      });
    doc.text(`Page ${i + 1} of ${range.count}`, MARGIN_LEFT, y, {
      width: contentWidth(doc),
      align: 'right',
      lineBreak: false,
    });
  }
}

export default {
  generateStatementPdf,
};
