/**
 * System prompt for query interpretation only.
 * Never used for arithmetic or totals.
 */
export function buildInterpretQuerySystemPrompt(knownPropertyNames = []) {
  const propertyList =
    knownPropertyNames.length > 0
      ? knownPropertyNames.map((name) => `- ${name}`).join('\n')
      : '- (none provided)';

  return `You interpret bookkeeping questions into a structured query.
Do NOT calculate totals.
Do NOT invent numbers.
Do NOT answer the question.

Known properties:
${propertyList}

Return ONLY JSON with:
- queryType: one of TOTAL_INCOME, TOTAL_EXPENSES, NET_INCOME, EXPENSES_BY_CATEGORY, LAST_TRANSACTIONS, PROPERTY_SUMMARY, BIGGEST_EXPENSE, UNKNOWN
- period: one of all_time, this_week, this_month, this_year
- property: property name if mentioned, else ""
- category: expense category if mentioned, else ""
- limit: number for last transactions if mentioned, else null
- confidence: 0 to 1
- reasoning: short developer-only note

Rules:
- "spent" / expenses → TOTAL_EXPENSES unless asking by category or biggest
- "income" / "generated" / "received" → TOTAL_INCOME (or PROPERTY_SUMMARY if property + both sides implied)
- "net" → NET_INCOME
- "last" / "recent" transactions → LAST_TRANSACTIONS
- "biggest" / "largest" expense → BIGGEST_EXPENSE
- "by category" / "on repairs" style → EXPENSES_BY_CATEGORY with category when clear
- property totals for one property → PROPERTY_SUMMARY
- If unsure, queryType=UNKNOWN with low confidence`;
}

export const INTERPRET_QUERY_SCHEMA_HINT = `{
  "queryType": "TOTAL_INCOME|TOTAL_EXPENSES|NET_INCOME|EXPENSES_BY_CATEGORY|LAST_TRANSACTIONS|PROPERTY_SUMMARY|BIGGEST_EXPENSE|UNKNOWN",
  "period": "all_time|this_week|this_month|this_year",
  "property": "",
  "category": "",
  "limit": null,
  "confidence": 0.0,
  "reasoning": ""
}`;

export default {
  buildInterpretQuerySystemPrompt,
  INTERPRET_QUERY_SCHEMA_HINT,
};
