import { createMetaApiClient } from '../meta/MetaApiClient.js';
import { normalizeWhatsAppPhoneNumber } from '../delivery/phoneNumber.js';

/**
 * Sends a plain-text WhatsApp Cloud API message via the shared MetaApiClient pipeline.
 * Returns { success, data, error } — does not throw for operational failures.
 */
export async function sendWhatsAppText(to, body, deps = {}) {
  const metaClient = deps.metaClient || createMetaApiClient();

  if (!body || !String(body).trim()) {
    return {
      success: false,
      data: null,
      error: {
        code: 'INVALID_MESSAGE',
        message: 'Message body is required',
      },
    };
  }

  const phone = normalizeWhatsAppPhoneNumber(to);
  if (!phone.ok) {
    return {
      success: false,
      data: null,
      error: phone.error,
    };
  }

  const result = await metaClient.sendMessage({
    messaging_product: 'whatsapp',
    to: phone.phoneNumber,
    type: 'text',
    text: {
      preview_url: false,
      body: String(body),
    },
  });

  if (!result.success) {
    console.error(
      `[whatsappSend] Send failure code=${result.error?.code} message=${result.error?.message}`,
    );
    return result;
  }

  const messageId = result.data?.messages?.[0]?.id || null;
  console.log(`[whatsappSend] Send success messageId=${messageId}`);

  return {
    success: true,
    data: {
      messageId,
    },
    error: null,
  };
}

export default {
  sendWhatsAppText,
};
