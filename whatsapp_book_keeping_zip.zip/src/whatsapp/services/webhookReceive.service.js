import { extractIncomingMessages } from './webhookPayload.service.js';
import { routeMessage } from './MessageRouter.js';
import { truncateSenderId } from '../../utils/safeLog.js';
import { markMessageProcessed } from '../../services/MessageIdService.js';

/**
 * Validates the inbound webhook body, extracts messages, and dispatches
 * routing asynchronously (fire-and-forget). Always safe for Meta timeouts.
 */
export function receiveWebhook(payload) {
  const messages = extractIncomingMessages(payload);

  if (messages.length === 0) {
    console.log('[WhatsAppWebhook] No inbound messages (status/update only) — acknowledging');
    return { accepted: true, messageCount: 0 };
  }

  console.log(`[WhatsAppWebhook] Accepted ${messages.length} message(s) for async routing`);

  for (const message of messages) {
    logSafeMessageSummary(message);

    setImmediate(async () => {
      try {
        // Prevent duplicate processing of the same WhatsApp message.
        const inserted = await markMessageProcessed(message.messageId);

        if (!inserted) {
          console.log(
            `[WhatsAppWebhook] Duplicate message ignored messageId=${message.messageId}`,
          );
          return;
        }

        await routeMessage(message);
      } catch (err) {
        console.error(
          `[MessageRouter] Unhandled error messageId=${message.messageId} sender=${truncateSenderId(message.senderId)}:`,
          err instanceof Error ? err.stack || err.message : err,
        );
      }
    });
  }

  return { accepted: true, messageCount: messages.length };
}

function logSafeMessageSummary(message) {
  const parts = [
    `type=${message.messageType}`,
    `messageId=${message.messageId}`,
    `sender=${truncateSenderId(message.senderId)}`,
  ];

  if (message.messageType === 'text') {
    parts.push(`textLength=${message.text?.length ?? 0}`);
  }

  if (message.messageType === 'audio') {
    parts.push(`hasMedia=${Boolean(message.audio?.id)}`);
    parts.push(`voice=${Boolean(message.audio?.voice)}`);
  }

  if (message.messageType === 'unsupported') {
    parts.push(`unsupportedType=${message.unsupportedType ?? 'unknown'}`);
  }

  console.log(`[WhatsAppWebhook] ${parts.join(' ')}`);
}

export default {
  receiveWebhook,
};