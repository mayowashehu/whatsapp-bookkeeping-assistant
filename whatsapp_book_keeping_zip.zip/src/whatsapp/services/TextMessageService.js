import { classifyMessage } from '../../ai/MessageClassifier.js';
import { parseTransaction } from '../../ai/parsing/TransactionParser.js';
import { buildCorrectionPatch } from '../../services/buildCorrectionPatch.js';
import * as DraftManager from '../../services/draft/DraftManager.js';
import * as QueryManager from '../../services/query/QueryManager.js';
import { handleStatementRequest } from '../../statement/StatementRequestService.js';
import { getKnownProperties } from '../../services/propertyLookup.service.js';
import { logInternalError, logProcessingEvent } from '../../utils/safeLog.js';
import { SAFE_WHATSAPP_FALLBACK_REPLY } from './safeReply.js';
import { sendWhatsAppText } from './whatsappSend.service.js';
import { UNKNOWN_WHATSAPP_REPLY } from './unknownReply.js';
function isCancelCommand(text) {
  if (typeof text !== 'string') {
    return false;
  }

  const normalized = text.trim().toLowerCase();

  return [
    'cancel',
    'discard',
    'abort',
    'never mind',
    'nevermind',
    'forget it',
    'stop',
  ].includes(normalized);
}

/**
 * Thin WhatsApp text handler — classifies, delegates, always replies.
 */
export async function handleTextMessage(message) {
  const messageId = message?.messageId;
  const text = message?.text;
  const fromNumber = message?.senderId || message?.phoneNumber;
  const startedAt = Date.now();
  let intent = 'none';
  let status = 'ok';

  try {
   let result;

if (isCancelCommand(text)) {
  intent = 'CANCEL';

  result = await DraftManager.handleCancel({
    fromNumber,
  });
} else {
  const classification = await classifyMessage(text);
  intent = classification.intent;

  result = await routeByIntent({
    intent: classification.intent,
    text,
    fromNumber,
  });
}

    const replyText = result?.replyText || SAFE_WHATSAPP_FALLBACK_REPLY;
    if (!result?.replyText) {
      status = 'fallback_no_result';
    }

    const sendResult = await sendWhatsAppText(fromNumber, replyText);
    if (!sendResult.success) {
      status = 'send_failed';
      logInternalError(
        'TextMessageService',
        new Error(sendResult.error?.message || 'Send failed'),
        { messageId, senderId: fromNumber },
      );
      // Still attempt a final safe fallback if the business reply failed to send.
      if (replyText !== SAFE_WHATSAPP_FALLBACK_REPLY) {
        await sendWhatsAppText(fromNumber, SAFE_WHATSAPP_FALLBACK_REPLY);
      }
    }

    logProcessingEvent('TextMessageService', {
      messageId,
      intent,
      status,
      durationMs: Date.now() - startedAt,
      senderId: fromNumber,
    });
  } catch (err) {
    status = 'error';
    logInternalError('TextMessageService', err, { messageId, senderId: fromNumber });

    try {
      await sendWhatsAppText(fromNumber, SAFE_WHATSAPP_FALLBACK_REPLY);
      status = 'fallback_sent';
    } catch (sendErr) {
      logInternalError('TextMessageService', sendErr, {
        messageId,
        senderId: fromNumber,
      });
      status = 'fallback_send_failed';
    }

    logProcessingEvent('TextMessageService', {
      messageId,
      intent,
      status,
      durationMs: Date.now() - startedAt,
      senderId: fromNumber,
    });
  }
}

async function routeByIntent({ intent, text, fromNumber }) {
  if (intent === 'LOG_ENTRY') {
    const knownProperties = await getKnownProperties();
    const parsed = await parseTransaction(text, { knownProperties });
    return DraftManager.handleLogEntry({
      fromNumber,
      parseResult: parsed,
    });
  }

  if (intent === 'CONFIRMATION') {
    return DraftManager.handleConfirmation({ fromNumber });
  }

  if (intent === 'CORRECTION') {
    const knownProperties = await getKnownProperties();
    const { patch } = await buildCorrectionPatch(text, { knownProperties });
    return DraftManager.handleCorrection({
      fromNumber,
      patch,
      knownProperties,
    });
  }

  if (intent === 'QUERY') {
    const knownProperties = await getKnownProperties();
    return QueryManager.handleQuery({
      text,
      knownProperties,
    });
  }

  if (intent === 'STATEMENT_REQUEST') {
    const knownProperties = await getKnownProperties();
    return handleStatementRequest({
      text,
      phoneNumber: fromNumber,
      knownProperties,
    });
  }

  if (intent === 'UNKNOWN') {
  return {
    replyText: UNKNOWN_WHATSAPP_REPLY,
  };
}

return null;
}

export default {
  handleTextMessage,
};
