/**
 * Safe user-facing fallback when processing fails unexpectedly.
 * Must not include internal error details.
 */
export const SAFE_WHATSAPP_FALLBACK_REPLY =
  'Sorry — something went wrong on my side. Please try again in a moment.';

export default {
  SAFE_WHATSAPP_FALLBACK_REPLY,
};
