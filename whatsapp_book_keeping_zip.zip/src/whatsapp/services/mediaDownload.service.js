import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createAppError } from '../../utils/createAppError.js';
import { createMetaApiClient } from '../meta/MetaApiClient.js';
import { assertSupportedAudioMimeType, normalizeMimeType } from './audioValidation.service.js';

const EXTENSION_BY_MIME = Object.freeze({
  'audio/ogg': '.ogg',
  'audio/opus': '.opus',
  'audio/mpeg': '.mp3',
  'audio/mp4': '.m4a',
  'audio/aac': '.aac',
});

/**
 * Downloads a WhatsApp Cloud API media object to the OS temp directory.
 * Uses the shared MetaApiClient gateway.
 */
export async function downloadWhatsAppMedia(mediaId, options = {}) {
  if (!mediaId) {
    throw createAppError('MEDIA_DOWNLOAD_INVALID_INPUT', 'mediaId is required');
  }

  const metaClient = options.metaClient || createMetaApiClient();
  const meta = await fetchMediaMetadata(metaClient, mediaId);
  const mimeType = assertSupportedAudioMimeType(options.mimeType || meta.mimeType);
  const filePath = await downloadBinaryToTempFile(metaClient, meta.url, mediaId, mimeType);

  return {
    filePath,
    mimeType,
    mediaId: String(mediaId),
  };
}

async function fetchMediaMetadata(metaClient, mediaId) {
  const result = await metaClient.getMediaMetadata(mediaId);
  if (!result.success) {
    throw createAppError(
      mapMediaErrorCode(result.error?.code, 'MEDIA_DOWNLOAD_FAILED'),
      result.error?.message || 'Failed to fetch WhatsApp media metadata',
    );
  }

  if (!result.data?.url) {
    throw createAppError(
      'MEDIA_DOWNLOAD_INVALID_RESPONSE',
      'WhatsApp media metadata response missing url',
    );
  }

  return {
    url: String(result.data.url),
    mimeType: result.data.mime_type ? normalizeMimeType(result.data.mime_type) : '',
  };
}

async function downloadBinaryToTempFile(metaClient, mediaUrl, mediaId, mimeType) {
  const result = await metaClient.requestBinary({ url: mediaUrl, retry: true });
  if (!result.success) {
    throw createAppError(
      mapMediaErrorCode(result.error?.code, 'MEDIA_DOWNLOAD_FAILED'),
      result.error?.message || 'Failed to download WhatsApp media binary',
    );
  }

  const buffer = result.data;
  if (!buffer?.length) {
    throw createAppError('MEDIA_DOWNLOAD_FAILED', 'Downloaded WhatsApp media file is empty');
  }

  const extension = EXTENSION_BY_MIME[mimeType] || '.bin';
  const fileName = `wa-audio-${mediaId}-${Date.now()}${extension}`;
  const filePath = path.join(os.tmpdir(), fileName);

  try {
    await fs.writeFile(filePath, buffer);
  } catch (err) {
    throw createAppError(
      'MEDIA_TEMP_WRITE_FAILED',
      `Failed to write temporary audio file: ${err.message}`,
      { cause: err },
    );
  }

  return filePath;
}

function mapMediaErrorCode(code, fallback) {
  if (code === 'WHATSAPP_TIMEOUT') return 'MEDIA_DOWNLOAD_TIMEOUT';
  if (code === 'WHATSAPP_AUTH_ERROR') return 'MEDIA_DOWNLOAD_CONFIG_ERROR';
  return fallback;
}

/**
 * Deletes a temporary file if it exists. Never throws (logs instead).
 */
export async function deleteTempAudioFile(filePath) {
  if (!filePath) {
    return;
  }

  try {
    await fs.unlink(filePath);
  } catch (err) {
    if (err?.code !== 'ENOENT') {
      console.error(
        `[mediaDownload] Failed to delete temp file path=${filePath}: ${err.message}`,
      );
    }
  }
}

export default {
  downloadWhatsAppMedia,
  deleteTempAudioFile,
};
