import { classifyMessage } from '../../ai/MessageClassifier.js';
import { parseTransaction } from '../../ai/parsing/TransactionParser.js';
import { buildCorrectionPatch } from '../../services/buildCorrectionPatch.js';
import * as DraftManager from '../../services/draft/DraftManager.js';
import * as QueryManager from '../../services/query/QueryManager.js';
import { handleStatementRequest } from '../../statement/StatementRequestService.js';
import { getKnownProperties } from '../../services/propertyLookup.service.js';
import { createTranscriptionService } from '../../transcription/createTranscriptionService.js';
import { logInternalError, logProcessingEvent } from '../../utils/safeLog.js';
import {
  deleteTempAudioFile,
  downloadWhatsAppMedia,
} from './mediaDownload.service.js';
import { SAFE_WHATSAPP_FALLBACK_REPLY } from './safeReply.js';
import { sendWhatsAppText } from './whatsappSend.service.js';
import { UNKNOWN_WHATSAPP_REPLY } from './unknownReply.js';
function isCancelCommand(text) {
  if (typeof text !== 'string') {
    return false;
  }

  const normalized = text.trim().toLowerCase();

  return [
    'cancel',
    'discard',
    'abort',
    'never mind',
    'nevermind',
    'forget it',
    'stop',
  ].includes(normalized);
}

/**
 * Thin WhatsApp voice handler — always replies; never logs transcript text.
 */
export async function handleVoiceMessage(message) {
  const mediaId = message?.audio?.id;
  const messageId = message?.messageId;
  const fromNumber = message?.senderId || message?.phoneNumber;
  const startedAt = Date.now();
  let intent = 'none';
  let status = 'ok';
  let tempFilePath = null;

  try {
    if (!mediaId) {
      status = 'missing_media';
      logInternalError(
        'VoiceMessageService',
        new Error('Missing audio media id'),
        { messageId, senderId: fromNumber },
      );
      await sendWhatsAppText(fromNumber, SAFE_WHATSAPP_FALLBACK_REPLY);
      logProcessingEvent('VoiceMessageService', {
        messageId,
        intent,
        status: 'fallback_sent',
        durationMs: Date.now() - startedAt,
        senderId: fromNumber,
      });
      return;
    }

    const downloaded = await downloadWhatsAppMedia(mediaId, {
      mimeType: message.audio?.mimeType,
    });
    tempFilePath = downloaded.filePath;

    const transcriptionService = createTranscriptionService();
    const transcript = await transcriptionService.transcribe({
      filePath: downloaded.filePath,
      mimeType: downloaded.mimeType,
    });

    let result;

if (isCancelCommand(transcript.text)) {
  intent = 'CANCEL';

  result = await DraftManager.handleCancel({
    fromNumber,
  });
} else {
  const classification = await classifyMessage(transcript.text);
  intent = classification.intent;

  result = await routeByIntent({
    intent: classification.intent,
    text: transcript.text,
    fromNumber,
  });
}

    const replyText = result?.replyText || SAFE_WHATSAPP_FALLBACK_REPLY;
    if (!result?.replyText) {
      status = 'fallback_no_result';
    }

    const sendResult = await sendWhatsAppText(fromNumber, replyText);
    if (!sendResult.success) {
      status = 'send_failed';
      logInternalError(
        'VoiceMessageService',
        new Error(sendResult.error?.message || 'Send failed'),
        { messageId, senderId: fromNumber },
      );
      if (replyText !== SAFE_WHATSAPP_FALLBACK_REPLY) {
        await sendWhatsAppText(fromNumber, SAFE_WHATSAPP_FALLBACK_REPLY);
        status = 'fallback_sent';
      }
    }

    logProcessingEvent('VoiceMessageService', {
      messageId,
      intent,
      status,
      durationMs: Date.now() - startedAt,
      senderId: fromNumber,
    });
  } catch (err) {
    status = 'error';
    logInternalError('VoiceMessageService', err, { messageId, senderId: fromNumber });

    try {
      await sendWhatsAppText(fromNumber, SAFE_WHATSAPP_FALLBACK_REPLY);
      status = 'fallback_sent';
    } catch (sendErr) {
      logInternalError('VoiceMessageService', sendErr, {
        messageId,
        senderId: fromNumber,
      });
      status = 'fallback_send_failed';
    }

    logProcessingEvent('VoiceMessageService', {
      messageId,
      intent,
      status,
      durationMs: Date.now() - startedAt,
      senderId: fromNumber,
    });
  } finally {
    await deleteTempAudioFile(tempFilePath);
  }
}

async function routeByIntent({ intent, text, fromNumber }) {
  if (intent === 'LOG_ENTRY') {
    const knownProperties = await getKnownProperties();
    const parsed = await parseTransaction(text, { knownProperties });
    return DraftManager.handleLogEntry({
      fromNumber,
      parseResult: parsed,
    });
  }

  if (intent === 'CONFIRMATION') {
    return DraftManager.handleConfirmation({ fromNumber });
  }

  if (intent === 'CORRECTION') {
    const knownProperties = await getKnownProperties();
    const { patch } = await buildCorrectionPatch(text, { knownProperties });
    return DraftManager.handleCorrection({
      fromNumber,
      patch,
      knownProperties,
    });
  }

  if (intent === 'QUERY') {
    const knownProperties = await getKnownProperties();
    return QueryManager.handleQuery({
      text,
      knownProperties,
    });
  }

  if (intent === 'STATEMENT_REQUEST') {
    const knownProperties = await getKnownProperties();
    return handleStatementRequest({
      text,
      phoneNumber: fromNumber,
      knownProperties,
    });
  }

  if (intent === 'UNKNOWN') {
  return {
    replyText: UNKNOWN_WHATSAPP_REPLY,
  };
}

return null;
}

export default {
  handleVoiceMessage,
};
