import * as TextMessageService from './TextMessageService.js';
import * as VoiceMessageService from './VoiceMessageService.js';
import { logInternalError, logProcessingEvent, truncateSenderId } from '../../utils/safeLog.js';
import { SAFE_WHATSAPP_FALLBACK_REPLY } from './safeReply.js';
import { sendWhatsAppText } from './whatsappSend.service.js';
const UNSUPPORTED_MEDIA_REPLY =
  'I currently support text messages and voice notes only. Please send your bookkeeping request as text or a voice note.';

/**
 * MessageRouter — decides where a normalized inbound message should go.
 */
const handlers = {
  text: TextMessageService.handleTextMessage,
  audio: VoiceMessageService.handleVoiceMessage,
};

/**
 * Route a single normalized message to the matching handler.
 * Unsupported / unknown types still receive a safe WhatsApp fallback.
 */
export async function routeMessage(message) {
  const type = message?.messageType;
  const messageId = message?.messageId;
  const senderId = message?.senderId || message?.phoneNumber;
  const startedAt = Date.now();

  if (type === 'unsupported') {
  logProcessingEvent('MessageRouter', {
    messageId,
    intent: 'unsupported',
    status: 'unsupported',
    durationMs: Date.now() - startedAt,
    senderId,
    detail: `type=${message.unsupportedType ?? 'unknown'}`,
  });

  try {
    await sendWhatsAppText(senderId, UNSUPPORTED_MEDIA_REPLY);
  } catch (err) {
    logInternalError('MessageRouter', err, {
      messageId,
      senderId,
    });
  }

  return;
}

  const handler = handlers[type];

  if (!handler) {
    logProcessingEvent('MessageRouter', {
      messageId,
      intent: 'none',
      status: 'no_handler',
      durationMs: Date.now() - startedAt,
      senderId,
      detail: `type=${type}`,
    });
    await sendSafeFallback(senderId, messageId);
    return;
  }

  console.log(
    `[MessageRouter] Routing type=${type} messageId=${messageId} sender=${truncateSenderId(senderId)}`,
  );

  await handler(message);
}

async function sendSafeFallback(senderId, messageId) {
  try {
    await sendWhatsAppText(senderId, SAFE_WHATSAPP_FALLBACK_REPLY);
  } catch (err) {
    logInternalError('MessageRouter', err, { messageId, senderId });
  }
}

/**
 * Register an additional message-type handler (future expansion).
 */
export function registerHandler(messageType, handler) {
  if (typeof messageType !== 'string' || typeof handler !== 'function') {
    throw new Error('registerHandler requires a messageType string and handler function');
  }
  handlers[messageType] = handler;
}

export default {
  routeMessage,
  registerHandler,
};
