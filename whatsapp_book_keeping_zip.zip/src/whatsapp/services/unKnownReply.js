export const UNKNOWN_WHATSAPP_REPLY = `I didn't understand that.

You can:
• record income
• record expenses
• ask bookkeeping questions
• request a monthly statement`;

export default {
  UNKNOWN_WHATSAPP_REPLY,
};