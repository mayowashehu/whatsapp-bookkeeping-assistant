import dotenv from 'dotenv';

dotenv.config();

/**
 * Centralized environment configuration.
 */
const env = {
  nodeEnv: process.env.NODE_ENV || 'development',
  port: Number(process.env.PORT) || 5000,
  mongodbUri: process.env.MONGODB_URI || '',
  geminiApiKey: process.env.GEMINI_API_KEY || '',
  geminiModel: process.env.GEMINI_MODEL || 'gemini-2.0-flash',
  geminiClassifierModel:
    process.env.GEMINI_CLASSIFIER_MODEL ||
    process.env.GEMINI_MODEL ||
    'gemini-2.0-flash',
  geminiParserModel:
    process.env.GEMINI_PARSER_MODEL || process.env.GEMINI_MODEL || 'gemini-2.0-flash',
  geminiQueryModel:
    process.env.GEMINI_QUERY_MODEL || process.env.GEMINI_MODEL || 'gemini-2.0-flash',
  downloadTimeoutMs: Number(process.env.DOWNLOAD_TIMEOUT_MS) || 30_000,
  transcriptionTimeoutMs: Number(process.env.TRANSCRIPTION_TIMEOUT_MS) || 60_000,
  aiTimeoutMs: Number(process.env.AI_TIMEOUT_MS) || 30_000,
  classificationMinConfidence: Number(process.env.CLASSIFICATION_MIN_CONFIDENCE) || 0.7,
  queryLastN: Number(process.env.QUERY_LAST_N) || 5,
  whatsapp: {
    accessToken: process.env.WHATSAPP_ACCESS_TOKEN || '',
    phoneNumberId: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
    verifyToken: process.env.WHATSAPP_VERIFY_TOKEN || '',
    appSecret: process.env.META_APP_SECRET || '',
    graphApiVersion: process.env.WHATSAPP_GRAPH_API_VERSION || 'v21.0',
    apiTimeoutMs: Number(process.env.WHATSAPP_API_TIMEOUT_MS) || 30_000,
    apiMaxRetries: Number(process.env.WHATSAPP_API_MAX_RETRIES) || 3,
  },
};

export default env;
