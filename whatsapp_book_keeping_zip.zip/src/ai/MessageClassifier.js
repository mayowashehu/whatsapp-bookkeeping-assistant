import env from '../config/env.js';
import { createAIService } from './createAIService.js';
import {
  CLASSIFY_MESSAGE_SCHEMA_HINT,
  CLASSIFY_MESSAGE_SYSTEM_PROMPT,
} from '../prompts/classifyMessage.js';

export const CLASSIFICATION_INTENTS = Object.freeze([
  'LOG_ENTRY',
  'QUERY',
  'CONFIRMATION',
  'CORRECTION',
  'STATEMENT_REQUEST',
  'UNKNOWN',
]);

/**
 * Classifies user intent only.
 * Depends solely on the generic AIService contract — never on a concrete provider.
 *
 * @param {string} text
 * @param {{ aiService?: import('./AIService.js').AIService }} [options]
 * @returns {Promise<{ intent: string, confidence: number, reasoning: string }>}
 */
export async function classifyMessage(text, options = {}) {
  const trimmed = typeof text === 'string' ? text.trim() : '';

  if (!trimmed) {
    return {
      intent: 'UNKNOWN',
      confidence: 0,
      reasoning: 'Empty input.',
    };
  }

  const aiService = options.aiService || createAIService();

  let raw;
  try {
    raw = await aiService.completeJson({
      system: CLASSIFY_MESSAGE_SYSTEM_PROMPT,
      user: trimmed,
      schemaHint: CLASSIFY_MESSAGE_SCHEMA_HINT,
    });
  } catch (err) {
    return {
      intent: 'UNKNOWN',
      confidence: 0,
      reasoning: `Classification provider failure: ${err.message}`,
    };
  }

  return normalizeClassification(raw, env.classificationMinConfidence);
}

/**
 * Validates and normalizes provider JSON. Never trusts AI output blindly.
 * Exported for deterministic demonstration / tests without calling the AI provider.
 */
export function normalizeClassification(raw, minConfidence = 0.7) {
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return unknownResult('Malformed classification payload.');
  }

  const intent = typeof raw.intent === 'string' ? raw.intent.trim().toUpperCase() : null;
  const confidence = normalizeConfidence(raw.confidence);
  const reasoning =
    typeof raw.reasoning === 'string' && raw.reasoning.trim()
      ? raw.reasoning.trim()
      : 'No reasoning provided.';

  if (!intent || !CLASSIFICATION_INTENTS.includes(intent)) {
    return {
      intent: 'UNKNOWN',
      confidence: confidence ?? 0,
      reasoning: `Unsupported or missing intent: ${String(raw.intent)}.`,
    };
  }

  if (confidence === null) {
    return {
      intent: 'UNKNOWN',
      confidence: 0,
      reasoning: 'Missing or invalid confidence; refusing to guess.',
    };
  }

  if (intent !== 'UNKNOWN' && confidence < minConfidence) {
    return {
      intent: 'UNKNOWN',
      confidence,
      reasoning: `Low confidence (${confidence} < ${minConfidence}): ${reasoning}`,
    };
  }

  return {
    intent,
    confidence,
    reasoning,
  };
}

function normalizeConfidence(value) {
  if (typeof value !== 'number' || Number.isNaN(value) || !Number.isFinite(value)) {
    return null;
  }
  if (value < 0 || value > 1) {
    return null;
  }
  return value;
}

function unknownResult(reasoning) {
  return {
    intent: 'UNKNOWN',
    confidence: 0,
    reasoning,
  };
}

export default {
  classifyMessage,
  normalizeClassification,
  CLASSIFICATION_INTENTS,
};
