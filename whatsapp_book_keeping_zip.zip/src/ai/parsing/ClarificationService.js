/**
 * Produces exactly ONE concise clarification question.
 * Never asks vague questions like "Can you clarify?".
 *
 * @param {{
 *   missingFields: string[],
 *   propertyCandidates?: Array<{ name: string }>,
 *   draft?: object
 * }} input
 * @returns {string|null}
 */
export function generateClarificationQuestion(input) {
  const missingFields = Array.isArray(input?.missingFields) ? input.missingFields : [];
  if (missingFields.length === 0) {
    return null;
  }

  const field = missingFields[0];
  const candidates = Array.isArray(input?.propertyCandidates) ? input.propertyCandidates : [];

  switch (field) {
    case 'type':
      return 'Was this income or an expense?';
    case 'property':
      if (candidates.length > 1) {
        const names = candidates.map((item) => item.name).join(' or ');
        return `Which property was this for: ${names}?`;
      }
      return 'Which property was this for?';
    case 'amount':
      return 'What was the amount in naira?';
    case 'category':
      return 'What category was this expense?';
    case 'transactionDate':
      return 'What date was this transaction?';
    default:
      return `What is the ${field} for this transaction?`;
  }
}

export default {
  generateClarificationQuestion,
};
