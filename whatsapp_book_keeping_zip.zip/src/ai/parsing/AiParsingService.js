import env from '../../config/env.js';
import { createAIService } from '../createAIService.js';
import {
  PARSE_TRANSACTION_SCHEMA_HINT,
  buildParseTransactionSystemPrompt,
} from '../../prompts/parseTransaction.js';

/**
 * AI extraction only — no validation, normalization, or clarification.
 *
 * @param {string} text
 * @param {{ knownPropertyNames?: string[], aiService?: import('../AIService.js').AIService }} [options]
 * @returns {Promise<object>}
 */
export async function extractTransactionFields(text, options = {}) {
  const aiService =
    options.aiService ||
    createAIService({
      model: env.geminiParserModel,
    });

  const knownPropertyNames = Array.isArray(options.knownPropertyNames)
    ? options.knownPropertyNames
    : [];

  return aiService.completeJson({
    system: buildParseTransactionSystemPrompt(knownPropertyNames),
    user: text,
    schemaHint: PARSE_TRANSACTION_SCHEMA_HINT,
  });
}

export default {
  extractTransactionFields,
};
