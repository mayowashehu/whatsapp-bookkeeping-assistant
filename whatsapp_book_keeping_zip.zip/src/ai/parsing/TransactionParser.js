import { extractTransactionFields } from './AiParsingService.js';
import { generateClarificationQuestion } from './ClarificationService.js';
import { validateParsingOutput } from './ParsingValidator.js';
import { normalizeTransactionFields } from './TransactionNormalizer.js';

/**
 * TransactionParser — orchestration only.
 * AI extract → validate → normalize → clarify.
 * Never writes to the database and never replies on WhatsApp.
 *
 * @param {string} text
 * @param {{
 *   knownProperties: Array<{ id: string, name: string, aliases?: string[], active?: boolean }>,
 *   aiService?: import('../AIService.js').AIService,
 *   referenceDate?: Date
 * }} options
 */
export async function parseTransaction(text, options = {}) {
  const sourceText = typeof text === 'string' ? text.trim() : '';
  const knownProperties = Array.isArray(options.knownProperties) ? options.knownProperties : [];

  if (!sourceText) {
    return buildResult({
      draft: emptyDraft(sourceText),
      clarificationRequired: true,
      missingFields: ['type', 'property', 'amount', 'transactionDate'],
      clarificationQuestion: generateClarificationQuestion({
        missingFields: ['type'],
      }),
      reasoning: 'Empty input.',
    });
  }

  let raw;
  try {
    raw = await extractTransactionFields(sourceText, {
      knownPropertyNames: knownProperties.map((p) => p.name).filter(Boolean),
      aiService: options.aiService,
    });
  } catch (err) {
    return buildResult({
      draft: emptyDraft(sourceText),
      clarificationRequired: true,
      missingFields: ['type', 'property', 'amount', 'transactionDate'],
      clarificationQuestion: generateClarificationQuestion({
        missingFields: ['type'],
      }),
      reasoning: `AI extraction failed: ${err.message}`,
    });
  }

  const validation = validateParsingOutput(raw);
  if (!validation.ok) {
    const reason = [...validation.structuralErrors, ...validation.fieldIssues].join('; ');
    return buildResult({
      draft: emptyDraft(sourceText),
      clarificationRequired: true,
      missingFields: ['type', 'property', 'amount', 'transactionDate'],
      clarificationQuestion: generateClarificationQuestion({
        missingFields: ['type'],
      }),
      reasoning: `Validation failed: ${reason}`,
    });
  }

  const normalized = normalizeTransactionFields(validation.raw, {
    knownProperties,
    sourceText,
    referenceDate: options.referenceDate || new Date(),
  });

  const missingFields = [...normalized.missingFields];

  // Honor AI uncertainty flags without inventing values.
  if (normalized.aiClarificationRequired) {
    for (const field of normalized.aiMissingFields) {
      if (typeof field === 'string' && field && !missingFields.includes(field)) {
        // Only keep known draft fields.
        if (
          ['type', 'property', 'amount', 'category', 'transactionDate', 'description'].includes(
            field,
          )
        ) {
          // description is optional — skip forcing it
          if (field !== 'description') {
            missingFields.push(field);
          }
        }
      }
    }
    if (missingFields.length === 0) {
      // AI asked for clarification but did not name fields — require the first incomplete core field.
      for (const field of ['type', 'property', 'amount', 'category', 'transactionDate']) {
        if (field === 'category' && normalized.draft.type === 'income') {
          continue;
        }
        if (
          (field === 'type' && !normalized.draft.type) ||
          (field === 'property' && !normalized.draft.property) ||
          (field === 'amount' && !normalized.draft.amount) ||
          (field === 'category' && !normalized.draft.category) ||
          (field === 'transactionDate' && !normalized.draft.transactionDate)
        ) {
          missingFields.push(field);
          break;
        }
      }
    }
  }

  const uniqueMissing = [...new Set(missingFields)];
  const clarificationRequired = uniqueMissing.length > 0;

  const clarificationQuestion = clarificationRequired
    ? generateClarificationQuestion({
        missingFields: uniqueMissing,
        propertyCandidates: normalized.propertyCandidates,
        draft: normalized.draft,
      })
    : null;

  return buildResult({
    draft: {
      type: normalized.draft.type,
      property: normalized.draft.property,
      amount: normalized.draft.amount,
      category: normalized.draft.category,
      description: normalized.draft.description,
      transactionDate: normalized.draft.transactionDate,
      sourceText: normalized.draft.sourceText,
    },
    clarificationRequired,
    missingFields: uniqueMissing,
    clarificationQuestion,
    reasoning: normalized.reasoning || 'Parsed successfully.',
  });
}

function emptyDraft(sourceText) {
  return {
    type: '',
    property: null,
    amount: null,
    category: null,
    description: '',
    transactionDate: '',
    sourceText: sourceText || '',
  };
}

function buildResult({
  draft,
  clarificationRequired,
  missingFields,
  clarificationQuestion,
  reasoning,
}) {
  return {
    draft,
    clarificationRequired: Boolean(clarificationRequired),
    missingFields: Array.isArray(missingFields) ? missingFields : [],
    clarificationQuestion: clarificationQuestion || null,
    reasoning: reasoning || '',
  };
}

export default {
  parseTransaction,
};
