/**
 * Validates raw AI extraction output.
 * Does not normalize values and does not invent replacements.
 *
 * @returns {{
 *   ok: boolean,
 *   raw: object|null,
 *   structuralErrors: string[],
 *   fieldIssues: string[]
 * }}
 */
export function validateParsingOutput(raw) {
  const structuralErrors = [];
  const fieldIssues = [];

  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) {
    return {
      ok: false,
      raw: null,
      structuralErrors: ['AI output must be a JSON object'],
      fieldIssues: [],
    };
  }

  const requiredKeys = [
    'type',
    'property',
    'amount',
    'category',
    'description',
    'transactionDate',
    'clarificationRequired',
    'missingFields',
    'reasoning',
  ];

  for (const key of requiredKeys) {
    if (!(key in raw)) {
      structuralErrors.push(`Missing key: ${key}`);
    }
  }

  if (structuralErrors.length > 0) {
    return {
      ok: false,
      raw,
      structuralErrors,
      fieldIssues,
    };
  }

  if (typeof raw.type !== 'string') {
    fieldIssues.push('type must be a string');
  } else {
    const type = raw.type.trim().toLowerCase();
    if (type && type !== 'income' && type !== 'expense') {
      fieldIssues.push('type must be income or expense');
    }
  }

  if (typeof raw.property !== 'string') {
    fieldIssues.push('property must be a string');
  }

  if (
    raw.amount !== null &&
    (typeof raw.amount !== 'number' || Number.isNaN(raw.amount) || !Number.isFinite(raw.amount))
  ) {
    // Allow string amounts — normalizer will try; mark issue only if clearly wrong type object/boolean
    if (typeof raw.amount === 'boolean' || typeof raw.amount === 'object') {
      fieldIssues.push('amount must be a number, numeric string, or null');
    }
  }

  if (typeof raw.category !== 'string' && raw.category !== null) {
    fieldIssues.push('category must be a string or null');
  }

  if (typeof raw.description !== 'string') {
    fieldIssues.push('description must be a string');
  }

  if (typeof raw.transactionDate !== 'string') {
    fieldIssues.push('transactionDate must be a string');
  }

  if (typeof raw.clarificationRequired !== 'boolean') {
    fieldIssues.push('clarificationRequired must be a boolean');
  }

  if (!Array.isArray(raw.missingFields)) {
    fieldIssues.push('missingFields must be an array');
  } else if (!raw.missingFields.every((item) => typeof item === 'string')) {
    fieldIssues.push('missingFields must contain only strings');
  }

  if (typeof raw.reasoning !== 'string') {
    fieldIssues.push('reasoning must be a string');
  }

  return {
    ok: structuralErrors.length === 0 && fieldIssues.length === 0,
    raw,
    structuralErrors,
    fieldIssues,
  };
}

export default {
  validateParsingOutput,
};
