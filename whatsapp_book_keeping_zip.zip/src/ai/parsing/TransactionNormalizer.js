const WEEKDAYS = Object.freeze([
  'sunday',
  'monday',
  'tuesday',
  'wednesday',
  'thursday',
  'friday',
  'saturday',
]);

export const MONTHS = Object.freeze({
  january: 1,
  jan: 1,
  february: 2,
  feb: 2,
  march: 3,
  mar: 3,
  april: 4,
  apr: 4,
  may: 5,
  june: 6,
  jun: 6,
  july: 7,
  jul: 7,
  august: 8,
  aug: 8,
  september: 9,
  sep: 9,
  sept: 9,
  october: 10,
  oct: 10,
  november: 11,
  nov: 11,
  december: 12,
  dec: 12,
});

/**
 * Returns YYYY-MM-DD for "now" in Africa/Lagos.
 */
export function getLagosDateString(referenceDate = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Lagos',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).formatToParts(referenceDate);

  const year = parts.find((p) => p.type === 'year')?.value;
  const month = parts.find((p) => p.type === 'month')?.value;
  const day = parts.find((p) => p.type === 'day')?.value;
  return `${year}-${month}-${day}`;
}

function parseIsoDateOnly(value) {
  const match = /^(\d{4})-(\d{2})-(\d{2})$/.exec(value);
  if (!match) {
    return null;
  }
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  if (!isValidYmd(year, month, day)) {
    return null;
  }
  return formatYmd(year, month, day);
}

function isValidYmd(year, month, day) {
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return false;
  }
  const utc = new Date(Date.UTC(year, month - 1, day));
  return (
    utc.getUTCFullYear() === year &&
    utc.getUTCMonth() === month - 1 &&
    utc.getUTCDate() === day
  );
}

function formatYmd(year, month, day) {
  return `${String(year).padStart(4, '0')}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
}

export function addDaysToYmd(ymd, deltaDays) {
  const [year, month, day] = ymd.split('-').map(Number);
  const utc = new Date(Date.UTC(year, month - 1, day));
  utc.setUTCDate(utc.getUTCDate() + deltaDays);
  return formatYmd(utc.getUTCFullYear(), utc.getUTCMonth() + 1, utc.getUTCDate());
}

function weekdayIndex(ymd) {
  const [year, month, day] = ymd.split('-').map(Number);
  return new Date(Date.UTC(year, month - 1, day)).getUTCDay();
}

/**
 * Deterministic natural-language date parser (Africa/Lagos calendar day).
 * @returns {string|null} YYYY-MM-DD or null if unsupported/ambiguous
 */
export function normalizeTransactionDate(value, referenceDate = new Date()) {
  if (value === null || value === undefined) {
    return null;
  }

  const text = String(value).trim().toLowerCase().replace(/,/g, ' ').replace(/\s+/g, ' ');
  if (!text) {
    return null;
  }

  const today = getLagosDateString(referenceDate);

  if (text === 'today') {
    return today;
  }
  if (text === 'yesterday') {
    return addDaysToYmd(today, -1);
  }

  const iso = parseIsoDateOnly(text);
  if (iso) {
    return iso;
  }

  const lastWeekday = /^last\s+(sunday|monday|tuesday|wednesday|thursday|friday|saturday)$/.exec(
    text,
  );
  if (lastWeekday) {
    const target = WEEKDAYS.indexOf(lastWeekday[1]);
    const current = weekdayIndex(today);
    let delta = (current - target + 7) % 7;
    if (delta === 0) {
      delta = 7;
    }
    return addDaysToYmd(today, -delta);
  }

  const dayMonth = /^(\d{1,2})\s+([a-z]+)$/.exec(text);
  if (dayMonth) {
    return resolveDayMonth(Number(dayMonth[1]), dayMonth[2], today);
  }

  const monthDay = /^([a-z]+)\s+(\d{1,2})$/.exec(text);
  if (monthDay) {
    return resolveDayMonth(Number(monthDay[2]), monthDay[1], today);
  }

  return null;
}

function resolveDayMonth(day, monthToken, todayYmd) {
  const month = MONTHS[monthToken];
  if (!month) {
    return null;
  }
  const year = Number(todayYmd.slice(0, 4));
  if (!isValidYmd(year, month, day)) {
    return null;
  }
  return formatYmd(year, month, day);
}

/**
 * Normalize amount expressions to a positive integer NGN value.
 * Supports: 18000, 18k, 25,000, ₦25000, NGN 25000
 * @returns {number|null}
 */
export function normalizeAmount(value) {
  if (value === null || value === undefined || value === '') {
    return null;
  }

  if (typeof value === 'number') {
    if (!Number.isFinite(value) || value <= 0) {
      return null;
    }
    return Math.round(value);
  }

  let text = String(value).trim().toLowerCase();
  text = text.replace(/ngn/g, '').replace(/₦/g, '').replace(/,/g, '').replace(/\s+/g, '');

  if (!text) {
    return null;
  }

  const kMatch = /^(\d+(?:\.\d+)?)k$/.exec(text);
  if (kMatch) {
    const amount = Math.round(Number(kMatch[1]) * 1000);
    return amount > 0 ? amount : null;
  }

  if (!/^\d+(\.\d+)?$/.test(text)) {
    return null;
  }

  const amount = Math.round(Number(text));
  return amount > 0 ? amount : null;
}

/**
 * Collapse a property label for comparison.
 */
export function canonicalizePropertyLabel(value) {
  return String(value || '')
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

const NUMBER_WORDS = Object.freeze({
  zero: '0',
  one: '1',
  two: '2',
  three: '3',
  four: '4',
  five: '5',
  six: '6',
  seven: '7',
  eight: '8',
  nine: '9',
  ten: '10',
});

/**
 * Builds comparable variants so "Apartment Two" / "apt2" / "Apt 2" can match.
 * This does not invent properties — it only expands how labels are compared.
 */
export function propertyMatchKeys(value) {
  const raw = String(value || '').toLowerCase();
  const keys = new Set();

  const compact = canonicalizePropertyLabel(raw);
  if (compact) {
    keys.add(compact);
  }

  let withNumberWords = raw;
  for (const [word, digit] of Object.entries(NUMBER_WORDS)) {
    withNumberWords = withNumberWords.replace(new RegExp(`\\b${word}\\b`, 'g'), digit);
  }

  const compactNumbers = canonicalizePropertyLabel(withNumberWords);
  if (compactNumbers) {
    keys.add(compactNumbers);
  }

  for (const key of [...keys]) {
    if (key.includes('apartment')) {
      keys.add(key.replace(/apartment/g, 'apt'));
    }
    if (key.startsWith('apt') && !key.startsWith('apartment')) {
      keys.add(`apartment${key.slice(3)}`);
    }
  }

  return [...keys].filter(Boolean);
}

/**
 * Resolve a property mention against known properties.
 * Never invents properties.
 *
 * @returns {{
 *   property: { id: string, name: string }|null,
 *   status: 'matched'|'none'|'ambiguous',
 *   candidates: Array<{ id: string, name: string }>
 * }}
 */
export function resolveProperty(mention, knownProperties = []) {
  const needles = new Set(propertyMatchKeys(mention));
  if (needles.size === 0) {
    return { property: null, status: 'none', candidates: [] };
  }

  const active = (knownProperties || []).filter((p) => p && p.active !== false);
  const matches = [];

  for (const property of active) {
    const labels = [property.name, ...(property.aliases || [])];
    const labelKeys = new Set(labels.flatMap((label) => propertyMatchKeys(label)));
    const overlapped = [...needles].some((needle) => labelKeys.has(needle));
    if (overlapped) {
      matches.push({ id: String(property.id), name: property.name });
    }
  }

  const unique = [];
  const seen = new Set();
  for (const match of matches) {
    if (!seen.has(match.id)) {
      seen.add(match.id);
      unique.push(match);
    }
  }

  if (unique.length === 1) {
    return { property: unique[0], status: 'matched', candidates: unique };
  }
  if (unique.length > 1) {
    return { property: null, status: 'ambiguous', candidates: unique };
  }
  return { property: null, status: 'none', candidates: [] };
}

/**
 * Normalize validated AI output into canonical draft fields + issue list.
 * Does not invent missing values.
 */
export function normalizeTransactionFields(raw, { knownProperties = [], sourceText = '', referenceDate = new Date() } = {}) {
  const missingFields = [];
  const notes = [];

  const typeRaw = typeof raw.type === 'string' ? raw.type.trim().toLowerCase() : '';
  let type = null;
  if (typeRaw === 'income' || typeRaw === 'expense') {
    type = typeRaw;
  } else {
    missingFields.push('type');
  }

  const propertyResolution = resolveProperty(raw.property, knownProperties);
  let property = null;
  if (propertyResolution.status === 'matched') {
    property = propertyResolution.property;
  } else if (propertyResolution.status === 'ambiguous') {
    missingFields.push('property');
    notes.push('ambiguous_property');
  } else {
    missingFields.push('property');
  }

  const amount = normalizeAmount(raw.amount);
  if (amount === null) {
    missingFields.push('amount');
  }

  let category = null;
  if (type === 'income') {
    category = null;
  } else if (type === 'expense') {
    const categoryRaw =
      typeof raw.category === 'string'
        ? raw.category.trim()
        : raw.category === null || raw.category === undefined
          ? ''
          : String(raw.category).trim();
    if (!categoryRaw) {
      missingFields.push('category');
    } else {
      category = categoryRaw;
    }
  }

  const description =
    typeof raw.description === 'string' ? raw.description.trim() : '';

  const dateRaw =
    typeof raw.transactionDate === 'string' ? raw.transactionDate.trim() : '';
  let transactionDate = null;
  if (!dateRaw) {
    missingFields.push('transactionDate');
  } else {
    transactionDate = normalizeTransactionDate(dateRaw, referenceDate);
    if (!transactionDate) {
      missingFields.push('transactionDate');
      notes.push('unparseable_date');
    }
  }

  // Deduplicate missing fields while preserving order.
  const uniqueMissing = [...new Set(missingFields)];

  return {
    draft: {
      type: type || '',
      property,
      amount,
      category,
      description,
      transactionDate: transactionDate || '',
      sourceText: sourceText || '',
    },
    missingFields: uniqueMissing,
    propertyCandidates: propertyResolution.candidates,
    notes,
    aiClarificationRequired: Boolean(raw.clarificationRequired),
    aiMissingFields: Array.isArray(raw.missingFields) ? raw.missingFields : [],
    reasoning: typeof raw.reasoning === 'string' ? raw.reasoning.trim() : '',
  };
}

export default {
  normalizeTransactionFields,
  normalizeAmount,
  normalizeTransactionDate,
  resolveProperty,
  getLagosDateString,
  addDaysToYmd,
  canonicalizePropertyLabel,
  MONTHS,
};
