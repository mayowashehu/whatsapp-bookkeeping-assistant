import env from '../../config/env.js';
import { createAppError } from '../../utils/createAppError.js';
import { fetchWithTimeout } from '../../utils/fetchWithTimeout.js';

/**
 * Gemini (Google AI Studio) AI provider.
 * This is the ONLY module allowed to contain Gemini-specific completeJson logic.
 *
 * @param {{ model?: string }} [options]
 * @returns {import('../AIService.js').AIService}
 */
export function createGeminiAIService(options = {}) {
  const model = options.model || env.geminiClassifierModel;

  return {
    async completeJson({ system, user, schemaHint }) {
      if (!env.geminiApiKey) {
        throw createAppError('AI_CONFIG_ERROR', 'GEMINI_API_KEY is not configured');
      }

      if (!system || !user) {
        throw createAppError(
          'AI_INVALID_INPUT',
          'system and user are required for completeJson',
        );
      }

      const url =
        `https://generativelanguage.googleapis.com/v1beta/models/` +
        `${encodeURIComponent(model)}:generateContent`;

      const userContent = schemaHint
        ? `${user}\n\nRespond with JSON matching this shape:\n${schemaHint}`
        : user;

      const body = {
        systemInstruction: {
          parts: [{ text: system }],
        },
        contents: [
          {
            role: 'user',
            parts: [{ text: userContent }],
          },
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          temperature: 0,
        },
      };

      let response;
      try {
        response = await fetchWithTimeout(
          url,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-goog-api-key': env.geminiApiKey,
            },
            body: JSON.stringify(body),
          },
          env.aiTimeoutMs,
        );
      } catch (err) {
        if (err?.code === 'TIMEOUT') {
          throw createAppError(
            'AI_TIMEOUT',
            `AI request timed out after ${env.aiTimeoutMs}ms`,
            { cause: err },
          );
        }
        throw createAppError('AI_REQUEST_FAILED', `AI request failed: ${err.message}`, {
          cause: err,
        });
      }

      let payload;
      try {
        payload = await response.json();
      } catch (err) {
        throw createAppError(
          'AI_INVALID_RESPONSE',
          `AI API returned non-JSON envelope (HTTP ${response.status})`,
          { cause: err },
        );
      }

      if (!response.ok) {
        const apiMessage =
          payload?.error?.message || `HTTP ${response.status} ${response.statusText}`;
        throw createAppError('AI_PROVIDER_ERROR', `AI provider error: ${apiMessage}`);
      }

      const rawText = extractText(payload);
      if (!rawText) {
        throw createAppError(
          'AI_INVALID_RESPONSE',
          'AI API response did not include text content',
        );
      }

      try {
        const parsed = JSON.parse(rawText);
        if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
          throw new Error('Parsed JSON is not an object');
        }
        return parsed;
      } catch (err) {
        throw createAppError(
          'AI_INVALID_RESPONSE',
          'AI API response was not valid JSON object content',
          { cause: err },
        );
      }
    },
  };
}

function extractText(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) {
    return null;
  }

  const text = parts
    .map((part) => (typeof part?.text === 'string' ? part.text : ''))
    .join('')
    .trim();

  return text || null;
}

export default {
  createGeminiAIService,
};
