/**
 * TranscriptionService contract.
 *
 * Every provider implementation MUST expose:
 *
 *   async transcribe({ filePath, mimeType }) → { text: string, confidence: number|null }
 *
 * Rules:
 * - `text` is plain transcript text (no markdown wrappers).
 * - `confidence` is a number when the provider supplies one; otherwise `null`.
 * - Throw structured errors (createAppError) for failures — never return partial silent failures.
 *
 * The rest of the application must depend only on this contract via
 * `createTranscriptionService()` — never on a concrete provider.
 */

/**
 * @typedef {object} TranscriptionInput
 * @property {string} filePath Absolute path to a temporary audio file.
 * @property {string} mimeType Audio MIME type (may include parameters).
 */

/**
 * @typedef {object} TranscriptionResult
 * @property {string} text
 * @property {number|null} confidence
 */

/**
 * @typedef {object} TranscriptionService
 * @property {(input: TranscriptionInput) => Promise<TranscriptionResult>} transcribe
 */

export const TranscriptionServiceContract = Object.freeze({
  method: 'transcribe',
  resultShape: Object.freeze({ text: 'string', confidence: 'number|null' }),
});
