import fs from 'node:fs/promises';
import env from '../../config/env.js';
import { createAppError } from '../../utils/createAppError.js';
import { fetchWithTimeout } from '../../utils/fetchWithTimeout.js';

/**
 * Gemini (Google AI Studio) transcription provider.
 * This is the ONLY module allowed to contain Gemini-specific logic.
 *
 * @returns {import('../TranscriptionService.js').TranscriptionService}
 */
export function createGeminiTranscriptionService() {
  return {
    async transcribe({ filePath, mimeType }) {
      if (!env.geminiApiKey) {
        throw createAppError(
          'TRANSCRIPTION_CONFIG_ERROR',
          'GEMINI_API_KEY is not configured',
        );
      }

      if (!filePath || !mimeType) {
        throw createAppError(
          'TRANSCRIPTION_INVALID_INPUT',
          'filePath and mimeType are required for transcription',
        );
      }

      const baseMime = String(mimeType).split(';')[0].trim().toLowerCase();
      let audioBase64;

      try {
        const buffer = await fs.readFile(filePath);
        audioBase64 = buffer.toString('base64');
      } catch (err) {
        throw createAppError(
          'TRANSCRIPTION_READ_FAILED',
          `Failed to read audio file for transcription: ${err.message}`,
          { cause: err },
        );
      }

      const model = env.geminiModel;
      const url =
        `https://generativelanguage.googleapis.com/v1beta/models/` +
        `${encodeURIComponent(model)}:generateContent`;

      const body = {
        contents: [
          {
            parts: [
              {
                inline_data: {
                  mime_type: baseMime,
                  data: audioBase64,
                },
              },
              {
                text:
                  'Transcribe this voice note to plain text. ' +
                  'Return only the spoken words with no commentary, labels, or markdown.',
              },
            ],
          },
        ],
      };

      let response;
      try {
        response = await fetchWithTimeout(
          url,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-goog-api-key': env.geminiApiKey,
            },
            body: JSON.stringify(body),
          },
          env.transcriptionTimeoutMs,
        );
      } catch (err) {
        if (err?.code === 'TIMEOUT') {
          throw createAppError(
            'TRANSCRIPTION_TIMEOUT',
            `Transcription timed out after ${env.transcriptionTimeoutMs}ms`,
            { cause: err },
          );
        }
        throw createAppError(
          'TRANSCRIPTION_REQUEST_FAILED',
          `Transcription request failed: ${err.message}`,
          { cause: err },
        );
      }

      let payload;
      try {
        payload = await response.json();
      } catch (err) {
        throw createAppError(
          'TRANSCRIPTION_INVALID_RESPONSE',
          `Transcription API returned non-JSON (HTTP ${response.status})`,
          { cause: err },
        );
      }

      if (!response.ok) {
        const apiMessage =
          payload?.error?.message || `HTTP ${response.status} ${response.statusText}`;
        throw createAppError(
          'TRANSCRIPTION_PROVIDER_ERROR',
          `Transcription provider error: ${apiMessage}`,
        );
      }

      const text = extractTranscriptText(payload);

      if (!text) {
        throw createAppError(
          'TRANSCRIPTION_INVALID_RESPONSE',
          'Transcription API response did not include transcript text',
        );
      }

      // Gemini generateContent does not expose a transcription confidence score.
      return {
        text,
        confidence: null,
      };
    },
  };
}

function extractTranscriptText(payload) {
  const parts = payload?.candidates?.[0]?.content?.parts;
  if (!Array.isArray(parts)) {
    return null;
  }

  const text = parts
    .map((part) => (typeof part?.text === 'string' ? part.text : ''))
    .join('')
    .trim();

  return text || null;
}

export default {
  createGeminiTranscriptionService,
};
