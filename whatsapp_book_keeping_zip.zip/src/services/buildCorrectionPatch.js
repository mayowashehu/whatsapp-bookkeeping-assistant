import { parseTransaction } from '../ai/parsing/TransactionParser.js';

/**
 * Builds a structured correction patch from user text.
 * Lives outside the draft layer so CorrectionProcessor never calls AI.
 *
 * @returns {Promise<{ patch: object, parseResult: object }>}
 */
export async function buildCorrectionPatch(text, options = {}) {
  const parseResult = await parseTransaction(text, {
    knownProperties: options.knownProperties || [],
    aiService: options.aiService,
    referenceDate: options.referenceDate,
  });

  const draft = parseResult.draft || {};
  const patch = {};

  if (draft.type === 'income' || draft.type === 'expense') {
    patch.type = draft.type;
  }
  if (draft.property?.id) {
    patch.property = draft.property;
  }
  if (draft.amount !== null && draft.amount !== undefined) {
    patch.amount = draft.amount;
  }
  if (draft.type === 'income') {
    patch.category = null;
  } else if (draft.category) {
    patch.category = draft.category;
  }
  if (draft.description) {
    patch.description = draft.description;
  }
  if (draft.transactionDate) {
    patch.transactionDate = draft.transactionDate;
  }

  // Never allow correction text to overwrite original sourceText here.
  return { patch, parseResult };
}

export default {
  buildCorrectionPatch,
};
