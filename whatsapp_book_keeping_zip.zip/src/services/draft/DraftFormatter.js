/**
 * Formats user-facing WhatsApp messages for draft confirmation flows.
 */

export function formatConfirmationMessage(draftView) {
  const lines = [
    'Please confirm:',
    '',
    capitalize(draftView.type),
    draftView.propertyName,
    formatNaira(draftView.amount),
  ];

  if (draftView.type === 'expense' && draftView.category) {
    lines.push(draftView.category);
  }

  lines.push(formatDisplayDate(draftView.transactionDate));
  lines.push('');
  lines.push('Reply YES to save or tell me what to change.');

  return lines.join('\n');
}

export function formatClarificationMessage(question) {
  return String(question || 'Which detail should I use for this transaction?');
}

export function formatExistingDraftBlockingMessage(draftView) {
  return [
    'You already have a pending transaction to confirm:',
    '',
    capitalize(draftView.type),
    draftView.propertyName,
    formatNaira(draftView.amount),
    formatDisplayDate(draftView.transactionDate),
    '',
    'Please reply YES to save it, or tell me what to change, before logging a new one.',
  ].join('\n');
}

export function formatSavedMessage(draftView) {
  return [
    'Saved.',
    `${capitalize(draftView.type)} • ${draftView.propertyName} • ${formatNaira(draftView.amount)}`,
  ].join('\n');
}

export function formatNoDraftMessage() {
  return 'There is no pending transaction to confirm. Send a new income or expense first.';
}

export function formatCorrectionUnclearMessage() {
  return 'I could not tell what to change. Example: Change the amount to 20000';
}

export function toDraftView(pendingDraftDoc) {
  const entry = pendingDraftDoc?.draftEntry;
  if (!entry) {
    return null;
  }

  const propertyDoc = entry.property;
  const propertyName =
    propertyDoc && typeof propertyDoc === 'object' && propertyDoc.name
      ? propertyDoc.name
      : 'Unknown property';

  return {
    type: entry.type,
    propertyName,
    propertyId: propertyDoc?._id ? String(propertyDoc._id) : String(propertyDoc),
    amount: entry.amount,
    category: entry.category ?? null,
    description: entry.description || '',
    transactionDate: entry.transactionDate,
    sourceText: entry.sourceText,
  };
}

function formatNaira(amount) {
  const value = Number(amount) || 0;
  return `₦${value.toLocaleString('en-NG')}`;
}

function capitalize(value) {
  const text = String(value || '');
  if (!text) {
    return '';
  }
  return text.charAt(0).toUpperCase() + text.slice(1);
}

function formatDisplayDate(value) {
  if (!value) {
    return '';
  }

  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) {
    return String(value);
  }

  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Lagos',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export default {
  formatConfirmationMessage,
  formatClarificationMessage,
  formatExistingDraftBlockingMessage,
  formatSavedMessage,
  formatNoDraftMessage,
  formatCorrectionUnclearMessage,
  toDraftView,
};
