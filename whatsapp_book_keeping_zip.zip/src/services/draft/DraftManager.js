import { applyCorrectionPatch } from './CorrectionProcessor.js';
import { buildEntryPayloadFromDraft } from './ConfirmationProcessor.js';
import * as DraftFormatter from './DraftFormatter.js';
import * as defaultRepository from './DraftRepository.js';
import { mapParserDraftToDraftEntry } from './draftMapper.js';
const DRAFT_TTL_MS = 24 * 60 * 60 * 1000; // 24 hours

/**
 * DraftManager — sole orchestrator for draft lifecycle.
 * Parser/classifier remain outside; repositories handle persistence only.
 *
 * @param {{ repository?: typeof defaultRepository }} [deps]
 */
function isDraftExpired(draft) {
  if (!draft?.createdAt) {
    return false;
  }

  return Date.now() - new Date(draft.createdAt).getTime() > DRAFT_TTL_MS;
}

async function getActiveDraft(fromNumber, DraftRepository) {
  const draft = await DraftRepository.findPendingDraftByFromNumber(fromNumber);

  if (!draft) {
    return null;
  }

  if (!isDraftExpired(draft)) {
    return draft;
  }

  await DraftRepository.deletePendingDraft(fromNumber);

  return null;
}

export function createDraftManager(deps = {}) {
  const DraftRepository = deps.repository || defaultRepository;

  async function handleLogEntry({ fromNumber, parseResult }) {
    if (!fromNumber) {
      throw new Error('fromNumber is required');
    }

      if (parseResult.clarificationRequired) {

      await DraftRepository.createPendingDraft({
          fromNumber,
          draftEntry: mapParserDraftToDraftEntry(parseResult.draft),
          clarification: {
              awaiting: true,
              missingFields: parseResult.missingFields,
              question: parseResult.clarificationQuestion,
          },
      });

      return {
          state: 'AWAITING_CLARIFICATION',
          replyText: parseResult.clarificationQuestion,
      };
  }

    const existing = await DraftRepository.findPendingDraftByFromNumber(fromNumber);

if (existing && isDraftExpired(existing)) {
  await DraftRepository.deletePendingDraft(fromNumber);
} else if (existing) {
  const view = DraftFormatter.toDraftView(existing);

  return {
    state: 'PENDING_CONFIRMATION',
    replyText: DraftFormatter.formatExistingDraftBlockingMessage(view),
    pendingDraft: existing,
    entry: null,
  };
}

    const draftEntry = mapParserDraftToDraftEntry(parseResult.draft);
    await DraftRepository.createPendingDraft({
      fromNumber,
      draftEntry,
    });

    const populated = await DraftRepository.findPendingDraftByFromNumber(fromNumber);
    const view = DraftFormatter.toDraftView(populated);

    return {
      state: 'PENDING_CONFIRMATION',
      replyText: DraftFormatter.formatConfirmationMessage(view),
      pendingDraft: populated,
      entry: null,
    };
  }

  async function handleConfirmation({ fromNumber }) {
    if (!fromNumber) {
      throw new Error('fromNumber is required');
    }

    const existing = await DraftRepository.findPendingDraftByFromNumber(fromNumber);
    if (existing && isDraftExpired(existing)) {
  await DraftRepository.deletePendingDraft(fromNumber);

  return {
    state: 'EXPIRED',
    replyText:
      'Your pending draft expired. Please send the transaction again.',
    pendingDraft: null,
    entry: null,
  };
}
    if (!existing) {
      return {
        state: 'NO_DRAFT',
        replyText: DraftFormatter.formatNoDraftMessage(),
        pendingDraft: null,
        entry: null,
      };
    }

    const view = DraftFormatter.toDraftView(existing);
    const entryPayload = buildEntryPayloadFromDraft(existing.draftEntry, new Date());

    let entry;
    try {
      entry = await DraftRepository.confirmDraftAtomically({
        fromNumber,
        entryPayload,
      });
    } catch (err) {
      return {
        state: 'PENDING_CONFIRMATION',
        replyText:
          'I could not save that transaction yet. Your pending draft is still here — reply YES to try again.',
        pendingDraft: existing,
        entry: null,
        error: err.message,
      };
    }

    return {
      state: 'SAVED',
      replyText: DraftFormatter.formatSavedMessage(view),
      pendingDraft: null,
      entry,
    };
  }

  async function handleCancel({ fromNumber }) {
  if (!fromNumber) {
    throw new Error('fromNumber is required');
  }

  const existing = await DraftRepository.findPendingDraftByFromNumber(fromNumber);

  if (existing && isDraftExpired(existing)) {
  await DraftRepository.deletePendingDraft(fromNumber);

  return {
    state: 'EXPIRED',
    replyText:
      'Your pending draft had already expired.',
    pendingDraft: null,
    entry: null,
  };
}
  if (!existing) {
    return {
      state: 'NO_DRAFT',
      replyText: DraftFormatter.formatNoDraftMessage(),
      pendingDraft: null,
      entry: null,
    };
  }

  await DraftRepository.deletePendingDraft(fromNumber);

  return {
    state: 'CANCELLED',
    replyText: 'Draft discarded.',
    pendingDraft: null,
    entry: null,
  };
}

  async function handleCorrection({ fromNumber, patch, knownProperties, referenceDate }) {
    if (!fromNumber) {
      throw new Error('fromNumber is required');
    }

    const existing = await DraftRepository.findPendingDraftByFromNumber(fromNumber);
    if (existing && isDraftExpired(existing)) {
  await DraftRepository.deletePendingDraft(fromNumber);

  return {
    state: 'EXPIRED',
    replyText:
      'Your pending draft expired. Please send the transaction again.',
    pendingDraft: null,
    entry: null,
  };
}
    if (!existing) {
      return {
        state: 'NO_DRAFT',
        replyText: DraftFormatter.formatNoDraftMessage(),
        pendingDraft: null,
        entry: null,
      };
    }

    if (!patch || typeof patch !== 'object' || Object.keys(patch).length === 0) {
      return {
        state: 'PENDING_CONFIRMATION',
        replyText: DraftFormatter.formatCorrectionUnclearMessage(),
        pendingDraft: existing,
        entry: null,
      };
    }

    const corrected = applyCorrectionPatch(existing.draftEntry, patch, {
      knownProperties,
      referenceDate,
    });

    if (corrected.clarificationRequired) {
      return {
        state: 'PENDING_CONFIRMATION',
        replyText: DraftFormatter.formatClarificationMessage(corrected.clarificationQuestion),
        pendingDraft: existing,
        entry: null,
        missingFields: corrected.missingFields,
      };
    }

    const updated = await DraftRepository.updatePendingDraftEntry(
      fromNumber,
      corrected.draftEntry,
    );
    const view = DraftFormatter.toDraftView(updated);

    return {
      state: 'PENDING_CONFIRMATION',
      replyText: DraftFormatter.formatConfirmationMessage(view),
      pendingDraft: updated,
      entry: null,
      updated: true,
    };
  }

  return {
    handleLogEntry,
    handleConfirmation,
    handleCancel,
    handleCorrection,
  };
}

const defaultManager = createDraftManager();

export const handleLogEntry = defaultManager.handleLogEntry;
export const handleConfirmation = defaultManager.handleConfirmation;
export const handleCancel = defaultManager.handleCancel;
export const handleCorrection = defaultManager.handleCorrection;

export default {
  createDraftManager,
  handleLogEntry,
  handleConfirmation,
  handleCancel,
  handleCorrection,
};