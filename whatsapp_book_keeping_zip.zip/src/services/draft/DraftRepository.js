import mongoose from 'mongoose';
import Entry from '../../models/Entry.js';
import PendingDraft from '../../models/PendingDraft.js';

/**
 * Database operations for pending drafts and confirmed entries.
 * No business/orchestration logic.
 */
export async function findPendingDraftByFromNumber(fromNumber) {
  return PendingDraft.findOne({ fromNumber: String(fromNumber) })
    .populate('draftEntry.property')
    .exec();
}

export async function createPendingDraft({ fromNumber, draftEntry }) {
  return PendingDraft.create({
    fromNumber: String(fromNumber),
    draftEntry,
  });
}

export async function updatePendingDraft({
  fromNumber,
  draftEntry,
  clarification,
}) {
  const update = {};

  if (draftEntry !== undefined) {
    update.draftEntry = draftEntry;
  }

  if (clarification !== undefined) {
    update.clarification = clarification;
  }

  return PendingDraft.findOneAndUpdate(
    { fromNumber: String(fromNumber) },
    { $set: update },
    {
      new: true,
      runValidators: true,
    },
  )
    .populate('draftEntry.property')
    .exec();
}

export async function deletePendingDraft(fromNumber, session = null) {
  const options = session ? { session } : {};
  return PendingDraft.deleteOne({ fromNumber: String(fromNumber) }, options);
}

/**
 * Atomically save an Entry and delete the pending draft.
 * If anything fails, the pending draft remains intact.
 */
export async function confirmDraftAtomically({ fromNumber, entryPayload }) {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const [entry] = await Entry.create([entryPayload], { session });
    const deleteResult = await PendingDraft.deleteOne(
      { fromNumber: String(fromNumber) },
      { session },
    );

    if (deleteResult.deletedCount !== 1) {
      throw new Error('Pending draft was not deleted during confirmation');
    }

    await session.commitTransaction();
    return entry;
  } catch (err) {
    await session.abortTransaction();
    throw err;
  } finally {
    session.endSession();
  }
}

export default {
  findPendingDraftByFromNumber,
  createPendingDraft,
  updatePendingDraft,
  deletePendingDraft,
  confirmDraftAtomically,
};
