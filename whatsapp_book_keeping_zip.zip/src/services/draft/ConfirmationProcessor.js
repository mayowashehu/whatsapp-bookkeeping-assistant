/**
 * Confirmation-only logic: map a pending draft entry into an Entry payload.
 * Persistence is handled by the repository / DraftManager.
 */
export function buildEntryPayloadFromDraft(draftEntry, confirmedAt = new Date()) {
  if (!draftEntry) {
    throw new Error('draftEntry is required for confirmation');
  }

  const propertyId =
    draftEntry.property && typeof draftEntry.property === 'object' && draftEntry.property._id
      ? draftEntry.property._id
      : draftEntry.property;

  return {
    type: draftEntry.type,
    property: propertyId,
    amount: draftEntry.amount,
    category: draftEntry.type === 'income' ? null : draftEntry.category,
    description: draftEntry.description || '',
    sourceText: draftEntry.sourceText,
    transactionDate: draftEntry.transactionDate,
    confirmedAt,
    status: 'confirmed',
  };
}

export default {
  buildEntryPayloadFromDraft,
};
