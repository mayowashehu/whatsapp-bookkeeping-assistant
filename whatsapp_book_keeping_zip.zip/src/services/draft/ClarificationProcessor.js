import { resolveProperty } from '../../ai/parsing/TransactionNormalizer.js';
import { generateClarificationQuestion } from '../../ai/parsing/ClarificationService.js';

/**
 * Applies ONE clarification answer to an existing pending draft.
 *
 * Pure business logic.
 * No database.
 * No WhatsApp.
 * No AI parsing.
 */
export function applyClarificationAnswer(
  pendingDraft,
  answer,
  options = {},
) {
  if (!pendingDraft?.clarification?.awaiting) {
    return {
      completed: false,
      error: 'Draft is not awaiting clarification.',
    };
  }

  const knownProperties = Array.isArray(options.knownProperties)
    ? options.knownProperties
    : [];

  const draftEntry =
    typeof pendingDraft.draftEntry?.toObject === 'function'
      ? pendingDraft.draftEntry.toObject()
      : { ...pendingDraft.draftEntry };

  const missingFields = [...pendingDraft.clarification.missingFields];

  if (missingFields.length === 0) {
    return {
      completed: true,
      draftEntry,
      clarification: {
        awaiting: false,
        missingFields: [],
        question: '',
      },
    };
  }

  const currentField = missingFields.shift();

  const handler = FIELD_HANDLERS[currentField];

  if (!handler) {
    return {
      completed: false,
      error: `Unsupported clarification field "${currentField}".`,
    };
  }

  const parsed = handler(answer, {
    knownProperties,
    draftEntry,
    referenceDate: options.referenceDate,
  });

  if (!parsed.ok) {
    return {
      completed: false,
      error: parsed.error,
    };
  }

  draftEntry[currentField] = parsed.value;

  if (missingFields.length === 0) {
    return {
      completed: true,
      draftEntry,
      clarification: {
        awaiting: false,
        missingFields: [],
        question: '',
      },
    };
  }

  return {
    completed: false,
    draftEntry,
    clarification: {
      awaiting: true,
      missingFields,
      question: generateClarificationQuestion({
        missingFields,
        draft: draftEntry,
      }),
    },
  };
}

/**
 * Field-specific parsers.
 * Easy to extend later.
 */
const FIELD_HANDLERS = {
  amount(answer) {
    const value = Number(String(answer).replace(/,/g, '').trim());

    if (!Number.isFinite(value) || value <= 0) {
      return {
        ok: false,
        error: 'Please enter a valid amount.',
      };
    }

    return {
      ok: true,
      value,
    };
  },

  property(answer, { knownProperties }) {
    const resolved = resolveProperty(
      String(answer),
      knownProperties,
    );

    if (resolved.status !== 'matched') {
      return {
        ok: false,
        error: 'I could not find that property. Please try again.',
      };
    }

    return {
      ok: true,
      value: resolved.property,
    };
  },

  transactionDate(answer) {
    const date = new Date(answer);

    if (Number.isNaN(date.getTime())) {
      return {
        ok: false,
        error: 'Please enter a valid date.',
      };
    }

    return {
      ok: true,
      value: date,
    };
  },

  category(answer) {
    const value = String(answer).trim().toLowerCase();

    if (!value) {
      return {
        ok: false,
        error: 'Category cannot be empty.',
      };
    }

    return {
      ok: true,
      value,
    };
  },

  type(answer) {
    const value = String(answer).trim().toLowerCase();

    if (!['income', 'expense'].includes(value)) {
      return {
        ok: false,
        error: 'Type must be income or expense.',
      };
    }

    return {
      ok: true,
      value,
    };
  },

  description(answer) {
    return {
      ok: true,
      value: String(answer).trim(),
    };
  },
};

export default {
  applyClarificationAnswer,
};