/**
 * Maps a validated parser draft into a PendingDraft.draftEntry document shape.
 */
export function mapParserDraftToDraftEntry(parserDraft) {
  if (!parserDraft?.property?.id) {
    throw new Error('Parser draft is missing a matched property id');
  }
  if (!parserDraft.type || !parserDraft.amount || !parserDraft.transactionDate) {
    throw new Error('Parser draft is incomplete');
  }
  if (parserDraft.type === 'expense' && !parserDraft.category) {
    throw new Error('Expense draft is missing category');
  }

  return {
    type: parserDraft.type,
    property: parserDraft.property.id,
    amount: parserDraft.amount,
    category: parserDraft.type === 'income' ? null : parserDraft.category,
    description: parserDraft.description || '',
    sourceText: parserDraft.sourceText,
    transactionDate: toLagosNoonDate(parserDraft.transactionDate),
  };
}

function toLagosNoonDate(isoDate) {
  // YYYY-MM-DD from parser → stable Date at noon Lagos (UTC+1, no DST).
  if (isoDate instanceof Date) {
    return isoDate;
  }
  return new Date(`${String(isoDate)}T12:00:00+01:00`);
}

export default {
  mapParserDraftToDraftEntry,
};
