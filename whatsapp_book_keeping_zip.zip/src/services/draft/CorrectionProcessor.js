import {
  normalizeAmount,
  normalizeTransactionDate,
  resolveProperty,
} from '../../ai/parsing/TransactionNormalizer.js';
import { generateClarificationQuestion } from '../../ai/parsing/ClarificationService.js';

/**
 * Applies a structured correction patch onto an existing pending draft entry.
 * Never calls AI. Never touches sourceText unless explicitly allowed (ignored by default).
 *
 * @param {object} currentEntry DB-shaped draftEntry (property may be ObjectId or populated)
 * @param {object} patch Structured patch from outside this layer
 * @param {{ knownProperties: Array, referenceDate?: Date }} options
 */
export function applyCorrectionPatch(currentEntry, patch, options = {}) {
  const knownProperties = Array.isArray(options.knownProperties) ? options.knownProperties : [];
  const referenceDate = options.referenceDate || new Date();
  const safePatch = patch && typeof patch === 'object' ? patch : {};

  const next = {
    type: currentEntry.type,
    property: extractPropertyId(currentEntry.property),
    amount: currentEntry.amount,
    category: currentEntry.category ?? null,
    description: currentEntry.description || '',
    sourceText: currentEntry.sourceText,
    transactionDate: currentEntry.transactionDate,
  };

  const missingFields = [];
  let propertyCandidates = [];

  if (Object.prototype.hasOwnProperty.call(safePatch, 'type')) {
    const type = String(safePatch.type || '')
      .trim()
      .toLowerCase();
    if (type !== 'income' && type !== 'expense') {
      missingFields.push('type');
    } else {
      next.type = type;
    }
  }

  if (Object.prototype.hasOwnProperty.call(safePatch, 'property')) {
    const mention =
      safePatch.property && typeof safePatch.property === 'object'
        ? safePatch.property.name || safePatch.property.id
        : safePatch.property;
    const resolved = resolveProperty(mention, knownProperties);
    propertyCandidates = resolved.candidates;
    if (resolved.status === 'matched') {
      next.property = resolved.property.id;
    } else {
      missingFields.push('property');
    }
  }

  if (Object.prototype.hasOwnProperty.call(safePatch, 'amount')) {
    const amount = normalizeAmount(safePatch.amount);
    if (amount === null) {
      missingFields.push('amount');
    } else {
      next.amount = amount;
    }
  }

  if (Object.prototype.hasOwnProperty.call(safePatch, 'description')) {
    next.description =
      typeof safePatch.description === 'string' ? safePatch.description.trim() : '';
  }

  if (Object.prototype.hasOwnProperty.call(safePatch, 'transactionDate')) {
    const iso = normalizeTransactionDate(safePatch.transactionDate, referenceDate);
    if (!iso) {
      missingFields.push('transactionDate');
    } else {
      next.transactionDate = new Date(`${iso}T12:00:00+01:00`);
    }
  }

  // Category rules after type is known.
  if (next.type === 'income') {
    next.category = null;
  } else if (Object.prototype.hasOwnProperty.call(safePatch, 'category')) {
    const category =
      typeof safePatch.category === 'string' ? safePatch.category.trim() : '';
    if (!category) {
      missingFields.push('category');
    } else {
      next.category = category;
    }
  } else if (next.type === 'expense' && !next.category) {
    missingFields.push('category');
  }

  // Validate full draft completeness after patch.
  if (!next.type) missingFields.push('type');
  if (!next.property) missingFields.push('property');
  if (!next.amount || next.amount <= 0) missingFields.push('amount');
  if (!next.transactionDate) missingFields.push('transactionDate');
  if (next.type === 'expense' && !next.category) missingFields.push('category');

  const uniqueMissing = [...new Set(missingFields)];
  const clarificationRequired = uniqueMissing.length > 0;

  return {
    draftEntry: {
      type: next.type,
      property: next.property,
      amount: next.amount,
      category: next.type === 'income' ? null : next.category,
      description: next.description,
      sourceText: next.sourceText,
      transactionDate: next.transactionDate,
    },
    clarificationRequired,
    missingFields: uniqueMissing,
    clarificationQuestion: clarificationRequired
      ? generateClarificationQuestion({
          missingFields: uniqueMissing,
          propertyCandidates,
        })
      : null,
  };
}

function extractPropertyId(property) {
  if (!property) {
    return null;
  }
  if (typeof property === 'object' && property._id) {
    return String(property._id);
  }
  return String(property);
}

export default {
  applyCorrectionPatch,
};
