import Property from '../models/Property.js';

/**
 * Loads active properties for callers that need to supply knownProperties
 * to the pure TransactionParser (parser never queries MongoDB itself).
 *
 * @returns {Promise<Array<{ id: string, name: string, aliases: string[], active: boolean }>>}
 */
export async function getKnownProperties() {
  const docs = await Property.find({ active: true }).select('name aliases active').lean();

  return docs.map((doc) => ({
    id: String(doc._id),
    name: doc.name,
    aliases: Array.isArray(doc.aliases) ? doc.aliases : [],
    active: doc.active !== false,
  }));
}

export default {
  getKnownProperties,
};
