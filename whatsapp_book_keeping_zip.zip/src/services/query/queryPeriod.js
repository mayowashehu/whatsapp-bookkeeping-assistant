import {
  addDaysToYmd,
  getLagosDateString,
} from '../../ai/parsing/TransactionNormalizer.js';

export const QUERY_PERIODS = Object.freeze({
  ALL_TIME: 'all_time',
  THIS_WEEK: 'this_week',
  THIS_MONTH: 'this_month',
  THIS_YEAR: 'this_year',
});

/**
 * Resolves a period key into optional Mongo date bounds (Africa/Lagos calendar).
 * Bounds are inclusive calendar days stored as Date at Lagos noon.
 *
 * @returns {{ period: string, startDate: Date|null, endDate: Date|null, label: string }}
 */
export function resolvePeriodBounds(period = QUERY_PERIODS.ALL_TIME, referenceDate = new Date()) {
  const today = getLagosDateString(referenceDate);

  if (!period || period === QUERY_PERIODS.ALL_TIME) {
    return {
      period: QUERY_PERIODS.ALL_TIME,
      startDate: null,
      endDate: null,
      label: 'all time',
    };
  }

  if (period === QUERY_PERIODS.THIS_MONTH) {
    const start = `${today.slice(0, 8)}01`;
    return {
      period,
      startDate: toLagosNoonDate(start),
      endDate: toLagosNoonDate(today),
      label: 'this month',
    };
  }

  if (period === QUERY_PERIODS.THIS_YEAR) {
    const start = `${today.slice(0, 4)}-01-01`;
    return {
      period,
      startDate: toLagosNoonDate(start),
      endDate: toLagosNoonDate(today),
      label: 'this year',
    };
  }

  if (period === QUERY_PERIODS.THIS_WEEK) {
    const [year, month, day] = today.split('-').map(Number);
    const weekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay(); // 0=Sun
    const daysFromMonday = (weekday + 6) % 7; // Monday-start week
    const start = addDaysToYmd(today, -daysFromMonday);
    return {
      period,
      startDate: toLagosNoonDate(start),
      endDate: toLagosNoonDate(today),
      label: 'this week',
    };
  }

  return {
    period: QUERY_PERIODS.ALL_TIME,
    startDate: null,
    endDate: null,
    label: 'all time',
  };
}

export function toLagosNoonDate(isoDate) {
  return new Date(`${String(isoDate)}T12:00:00+01:00`);
}

export default {
  QUERY_PERIODS,
  resolvePeriodBounds,
  toLagosNoonDate,
};
