import mongoose from 'mongoose';
import Entry from '../../models/Entry.js';
import { resolvePeriodBounds } from './queryPeriod.js';

/**
 * Read-only MongoDB queries/aggregations for confirmed entries only.
 * No formatting.
 */
export async function executeQuery(request) {
  const periodBounds = resolvePeriodBounds(request.period);
  const match = buildMatch(request, periodBounds);

  switch (request.queryType) {
    case 'TOTAL_INCOME':
      return {
        kind: 'total',
        type: 'income',
        total: await sumAmount({ ...match, type: 'income' }),
        periodBounds,
        request,
      };
    case 'TOTAL_EXPENSES':
      return {
        kind: 'total',
        type: 'expense',
        total: await sumAmount({ ...match, type: 'expense' }),
        periodBounds,
        request,
      };
    case 'NET_INCOME': {
      const income = await sumAmount({ ...match, type: 'income' });
      const expenses = await sumAmount({ ...match, type: 'expense' });
      return {
        kind: 'net',
        income,
        expenses,
        net: income - expenses,
        periodBounds,
        request,
      };
    }
    case 'EXPENSES_BY_CATEGORY':
      return {
        kind: 'expenses_by_category',
        rows: await aggregateExpensesByCategory(match, request.category),
        periodBounds,
        request,
      };
    case 'LAST_TRANSACTIONS':
      return {
        kind: 'last_transactions',
        rows: await findLastTransactions(match, request.limit),
        periodBounds,
        request,
      };
    case 'PROPERTY_SUMMARY': {
      const income = await sumAmount({ ...match, type: 'income' });
      const expenses = await sumAmount({ ...match, type: 'expense' });
      return {
        kind: 'property_summary',
        income,
        expenses,
        net: income - expenses,
        periodBounds,
        request,
      };
    }
    case 'BIGGEST_EXPENSE':
      return {
        kind: 'biggest_expense',
        entry: await findBiggestExpense(match),
        periodBounds,
        request,
      };
    default:
      return {
        kind: 'unknown',
        periodBounds,
        request,
      };
  }
}

function buildMatch(request, periodBounds) {
  const match = {
    status: 'confirmed',
  };

  if (request.property?.id) {
    match.property = new mongoose.Types.ObjectId(request.property.id);
  }

  if (periodBounds.startDate || periodBounds.endDate) {
    match.transactionDate = {};
    if (periodBounds.startDate) {
      match.transactionDate.$gte = startOfLagosDay(periodBounds.startDate);
    }
    if (periodBounds.endDate) {
      match.transactionDate.$lte = endOfLagosDay(periodBounds.endDate);
    }
  }

  return match;
}

function startOfLagosDay(date) {
  const ymd = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Lagos',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
  return new Date(`${ymd}T00:00:00+01:00`);
}

function endOfLagosDay(date) {
  const ymd = new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Africa/Lagos',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date);
  return new Date(`${ymd}T23:59:59.999+01:00`);
}

async function sumAmount(match) {
  const rows = await Entry.aggregate([
    { $match: match },
    { $group: { _id: null, total: { $sum: '$amount' } } },
  ]);
  return rows[0]?.total || 0;
}

async function aggregateExpensesByCategory(match, category) {
  const categoryMatch = {
    ...match,
    type: 'expense',
  };
  if (category) {
    categoryMatch.category = new RegExp(`^${escapeRegex(category)}$`, 'i');
  }

  return Entry.aggregate([
    { $match: categoryMatch },
    {
      $group: {
        _id: { $toLower: '$category' },
        total: { $sum: '$amount' },
        category: { $first: '$category' },
      },
    },
    { $sort: { total: -1 } },
  ]);
}

async function findLastTransactions(match, limit) {
  const n = Math.max(1, Math.min(Number(limit) || 5, 50));
  return Entry.find(match)
    .sort({ transactionDate: -1, createdAt: -1 })
    .limit(n)
    .populate('property', 'name')
    .lean();
}

async function findBiggestExpense(match) {
  return Entry.findOne({ ...match, type: 'expense' })
    .sort({ amount: -1, transactionDate: -1 })
    .populate('property', 'name')
    .lean();
}

function escapeRegex(value) {
  return String(value).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

export default {
  executeQuery,
};
