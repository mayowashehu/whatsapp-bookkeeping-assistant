import env from '../../config/env.js';
import { createAIService } from '../../ai/createAIService.js';
import { resolveProperty } from '../../ai/parsing/TransactionNormalizer.js';
import {
  INTERPRET_QUERY_SCHEMA_HINT,
  buildInterpretQuerySystemPrompt,
} from '../../prompts/interpretQuery.js';
import { QUERY_PERIODS } from './queryPeriod.js';

export const QUERY_TYPES = Object.freeze({
  TOTAL_INCOME: 'TOTAL_INCOME',
  TOTAL_EXPENSES: 'TOTAL_EXPENSES',
  NET_INCOME: 'NET_INCOME',
  EXPENSES_BY_CATEGORY: 'EXPENSES_BY_CATEGORY',
  LAST_TRANSACTIONS: 'LAST_TRANSACTIONS',
  PROPERTY_SUMMARY: 'PROPERTY_SUMMARY',
  BIGGEST_EXPENSE: 'BIGGEST_EXPENSE',
  UNKNOWN: 'UNKNOWN',
});

/**
 * Hybrid query interpreter: deterministic rules first, AI fallback only if needed.
 * Never calculates financial totals.
 */
export async function interpretQuery(text, options = {}) {
  const knownProperties = Array.isArray(options.knownProperties) ? options.knownProperties : [];
  const referenceDate = options.referenceDate || new Date();
  const trimmed = typeof text === 'string' ? text.trim() : '';

  if (!trimmed) {
    return unknownRequest('Empty query.');
  }

  const deterministic = interpretDeterministically(trimmed, knownProperties, referenceDate);
  if (deterministic) {
    return {
      ...deterministic,
      source: 'deterministic',
    };
  }

  const aiService =
    options.aiService ||
    createAIService({
      model: env.geminiQueryModel || env.geminiClassifierModel,
    });

  let raw;
  try {
    raw = await aiService.completeJson({
      system: buildInterpretQuerySystemPrompt(knownProperties.map((p) => p.name)),
      user: trimmed,
      schemaHint: INTERPRET_QUERY_SCHEMA_HINT,
    });
  } catch (err) {
    return unknownRequest(`AI interpretation failed: ${err.message}`);
  }

  return normalizeAiInterpretation(raw, knownProperties, referenceDate);
}

function interpretDeterministically(text, knownProperties, _referenceDate) {
  const lower = text.toLowerCase().replace(/\s+/g, ' ').trim();
  const period = detectPeriod(lower);
 const propertyDetection = detectProperty(lower, knownProperties);
const propertyMatch =
  propertyDetection.status === 'matched'
    ? propertyDetection.property
    : null;
    if (propertyDetection.status === "unmatched") {
  return {
    ...buildRequest({
      queryType: QUERY_TYPES.UNKNOWN,
      period,
      property: null,
      category,
      limit,
      confidence: 1,
      reasoning: "Unknown property mentioned.",
    }),
    unmatchedProperty: propertyDetection.unmatchedProperty,
  };
}
  const category = detectCategory(lower);
  const limit = detectLimit(lower) || env.queryLastN;

  // Last / recent transactions
  if (/\b(last|recent)\b/.test(lower) && /\b(transaction|transactions|entries|entry)\b/.test(lower)) {
    return buildRequest({
      queryType: QUERY_TYPES.LAST_TRANSACTIONS,
      period,
      property: propertyMatch,
      category: null,
      limit,
      confidence: 0.95,
      reasoning: 'Matched last transactions pattern.',
    });
  }

  // Biggest expense
  if (/\b(biggest|largest|highest)\b/.test(lower) && /\b(expense|spent|spending)\b/.test(lower)) {
    return buildRequest({
      queryType: QUERY_TYPES.BIGGEST_EXPENSE,
      period,
      property: propertyMatch,
      category: null,
      limit: 1,
      confidence: 0.95,
      reasoning: 'Matched biggest expense pattern.',
    });
  }

  // Expenses by category
  if (
    category &&
    (/\b(spent|spend|spending|expenses?|on)\b/.test(lower) || /\bby category\b/.test(lower))
  ) {
    return buildRequest({
      queryType: QUERY_TYPES.EXPENSES_BY_CATEGORY,
      period,
      property: propertyMatch,
      category,
      limit: null,
      confidence: 0.9,
      reasoning: 'Matched expenses by category pattern.',
    });
  }

  if (/\bby category\b/.test(lower) || /\bexpenses? by\b/.test(lower)) {
    return buildRequest({
      queryType: QUERY_TYPES.EXPENSES_BY_CATEGORY,
      period,
      property: propertyMatch,
      category: category || null,
      limit: null,
      confidence: 0.85,
      reasoning: 'Matched expenses grouped by category.',
    });
  }

  // Property summary (income + expenses + net for one property)
  if (
    propertyMatch &&
    (/\b(summary|totals?|overview|breakdown)\b/.test(lower) ||
      (/\bincome\b/.test(lower) && /\bexpense/.test(lower)))
  ) {
    return buildRequest({
      queryType: QUERY_TYPES.PROPERTY_SUMMARY,
      period,
      property: propertyMatch,
      category: null,
      limit: null,
      confidence: 0.9,
      reasoning: 'Matched property summary pattern.',
    });
  }

  // Net
  if (/\bnet\b/.test(lower)) {
    return buildRequest({
      queryType: propertyMatch ? QUERY_TYPES.PROPERTY_SUMMARY : QUERY_TYPES.NET_INCOME,
      period,
      property: propertyMatch,
      category: null,
      limit: null,
      confidence: 0.92,
      reasoning: 'Matched net income pattern.',
    });
  }

  // Income / rent generated for property → total income (6A)
  if (
    /\b(income|received|generated|rent|earning|earnings)\b/.test(lower) &&
    !/\b(expense|spent|spending)\b/.test(lower)
  ) {
    return buildRequest({
      queryType: QUERY_TYPES.TOTAL_INCOME,
      period,
      property: propertyMatch,
      category: null,
      limit: null,
      confidence: propertyMatch ? 0.93 : 0.88,
      reasoning: 'Matched total income pattern.',
    });
  }

  // Expenses / spent
  if (/\b(expense|expenses|spent|spend|spending|paid out)\b/.test(lower)) {
    return buildRequest({
      queryType: QUERY_TYPES.TOTAL_EXPENSES,
      period,
      property: propertyMatch,
      category: null,
      limit: null,
      confidence: 0.9,
      reasoning: 'Matched total expenses pattern.',
    });
  }

  // Property alone with "how much" → property summary
  if (propertyMatch && /\b(how much|total|for)\b/.test(lower)) {
    return buildRequest({
      queryType: QUERY_TYPES.PROPERTY_SUMMARY,
      period,
      property: propertyMatch,
      category: null,
      limit: null,
      confidence: 0.8,
      reasoning: 'Matched property how-much pattern.',
    });
  }

  return null;
}

function normalizeAiInterpretation(raw, knownProperties, _referenceDate) {
  if (!raw || typeof raw !== 'object') {
    return unknownRequest('Malformed AI interpretation.');
  }

  const confidence =
    typeof raw.confidence === 'number' && raw.confidence >= 0 && raw.confidence <= 1
      ? raw.confidence
      : null;

  if (confidence === null || confidence < 0.7) {
    return unknownRequest('Low or invalid interpretation confidence.');
  }

  const queryType = String(raw.queryType || '')
    .trim()
    .toUpperCase();
  if (!Object.values(QUERY_TYPES).includes(queryType) || queryType === QUERY_TYPES.UNKNOWN) {
    return unknownRequest('Unsupported or unknown query type from AI.');
  }

  const period = normalizePeriod(raw.period);
  const property =
    raw.property && String(raw.property).trim()
      ? resolveProperty(String(raw.property), knownProperties)
      : { property: null, status: 'none', candidates: [] };

  if (raw.property && String(raw.property).trim() && property.status !== 'matched') {
    return {
      ...buildRequest({
        queryType,
        period,
        property: null,
        category: normalizeCategory(raw.category),
        limit: normalizeLimit(raw.limit),
        confidence,
        reasoning: 'Property mentioned but not matched to a known property.',
      }),
      unmatchedProperty: String(raw.property).trim(),
      source: 'ai',
    };
  }

  return {
    ...buildRequest({
      queryType,
      period,
      property: property.status === 'matched' ? property.property : null,
      category: normalizeCategory(raw.category),
      limit: normalizeLimit(raw.limit),
      confidence,
      reasoning: typeof raw.reasoning === 'string' ? raw.reasoning : 'AI interpretation.',
    }),
    source: 'ai',
  };
}

function detectPeriod(lower) {
  if (/\bthis week\b/.test(lower) || /\bcurrent week\b/.test(lower)) {
    return QUERY_PERIODS.THIS_WEEK;
  }
  if (/\bthis month\b/.test(lower) || /\bcurrent month\b/.test(lower)) {
    return QUERY_PERIODS.THIS_MONTH;
  }
  if (/\bthis year\b/.test(lower) || /\bcurrent year\b/.test(lower)) {
    return QUERY_PERIODS.THIS_YEAR;
  }
  return QUERY_PERIODS.ALL_TIME;
}

function detectProperty(lower, knownProperties) {
  let best = null;

  for (const property of knownProperties || []) {
    const labels = [property.name, ...(property.aliases || [])];

    for (const label of labels) {
      const needle = String(label || "")
        .toLowerCase()
        .trim();

      if (!needle || !lower.includes(needle)) {
        continue;
      }

      if (!best || needle.length > best.len) {
        best = {
          property: {
            id: String(property.id),
            name: property.name,
          },
          len: needle.length,
        };
      }
    }
  }

  if (best) {
    return {
      status: "matched",
      property: best.property,
    };
  }

  // User appears to mention a property but it isn't one we know.
  const unknownMatch =
    /\b(?:apartment|apt|flat|unit|property)\s+[a-z0-9-]+\b/i.exec(lower);

  if (unknownMatch) {
    return {
      status: "unmatched",
      unmatchedProperty: unknownMatch[0],
    };
  }

  return {
    status: "none",
    property: null,
  };
}

function detectCategory(lower) {
  // Common expense categories mentioned in product examples
  const categories = [
    'repairs',
    'repair',
    'maintenance',
    'cleaning',
    'security',
    'plumbing',
    'electric',
    'electrical',
    'utilities',
    'service charge',
  ];
  for (const category of categories) {
    if (lower.includes(category)) {
      if (category === 'repair') return 'repairs';
      if (category === 'electric' || category === 'electrical') return 'electrical';
      return category;
    }
  }

  const onMatch = /\bon\s+([a-z][a-z\s]{1,30})$/i.exec(lower);
  if (onMatch && !/\bon\s+(this|the|my|a|an)\b/.test(lower)) {
    const value = onMatch[1].trim();
    if (!/(month|week|year|apartment|apt|property)/.test(value)) {
      return value;
    }
  }
  return null;
}

function detectLimit(lower) {
  const match = /\blast\s+(\d{1,2})\b/.exec(lower);
  if (match) {
    const n = Number(match[1]);
    return n > 0 ? n : null;
  }
  return null;
}

function normalizePeriod(value) {
  const period = String(value || '')
    .trim()
    .toLowerCase()
    .replace(/\s+/g, '_');
  if (Object.values(QUERY_PERIODS).includes(period)) {
    return period;
  }
  return QUERY_PERIODS.ALL_TIME;
}

function normalizeCategory(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim().toLowerCase();
  return trimmed || null;
}

function normalizeLimit(value) {
  if (typeof value === 'number' && value > 0) {
    return Math.min(Math.floor(value), 50);
  }
  return env.queryLastN;
}

function buildRequest({
  queryType,
  period,
  property,
  category,
  limit,
  confidence,
  reasoning,
}) {
  return {
    queryType,
    period: period || QUERY_PERIODS.ALL_TIME,
    property: property || null,
    category: category || null,
    limit: limit ?? env.queryLastN,
    confidence: confidence ?? 1,
    reasoning: reasoning || '',
  };
}

function unknownRequest(reasoning) {
  return {
    queryType: QUERY_TYPES.UNKNOWN,
    period: QUERY_PERIODS.ALL_TIME,
    property: null,
    category: null,
    limit: env.queryLastN,
    confidence: 0,
    reasoning,
    source: 'none',
  };
}

export default {
  interpretQuery,
  QUERY_TYPES,
};
