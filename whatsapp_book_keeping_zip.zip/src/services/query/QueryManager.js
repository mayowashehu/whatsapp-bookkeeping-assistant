import { interpretQuery, QUERY_TYPES } from './QueryInterpreter.js';
import * as QueryFormatter from './QueryFormatter.js';
import * as defaultRepository from './QueryRepository.js';

/**
 * QueryManager — sole orchestrator for read-only bookkeeping queries.
 *
 * @param {{ repository?: typeof defaultRepository }} [deps]
 */
export function createQueryManager(deps = {}) {
  const QueryRepository = deps.repository || defaultRepository;

  async function handleQuery({ text, knownProperties, aiService, referenceDate }) {
    const request = await interpretQuery(text, {
      knownProperties,
      aiService,
      referenceDate,
    });

    if (request.queryType === QUERY_TYPES.UNKNOWN) {
      return {
        replyText: QueryFormatter.formatUnknownQuery(),
        request,
        result: null,
      };
    }

    if (request.unmatchedProperty) {
      return {
        replyText: QueryFormatter.formatUnmatchedProperty(request.unmatchedProperty),
        request,
        result: null,
      };
    }

    const result = await QueryRepository.executeQuery(request);
    return {
      replyText: QueryFormatter.formatQueryResult(result),
      request,
      result,
    };
  }

  return { handleQuery };
}

const defaultManager = createQueryManager();

export const handleQuery = defaultManager.handleQuery;

export default {
  createQueryManager,
  handleQuery,
};
