/**
 * Formats concise WhatsApp replies for query results.
 * Lead with the answer. Never invent numbers.
 */

export function formatQueryResult(result) {
  if (!result || result.kind === 'unknown') {
    return 'I could not understand that question. Try asking about income, expenses, or last transactions.';
  }

  const periodLabel = result.periodBounds?.label || 'all time';
  const propertyName = result.request?.property?.name || null;
  const category = result.request?.category || null;

  switch (result.kind) {
    case 'total': {
      if (!result.total) {
        return noRecordsMessage({
          type: result.type,
          periodLabel,
          propertyName,
          category,
        });
      }
      if (result.type === 'income') {
        return `${formatNaira(result.total)} total income${scopeSuffix(periodLabel, propertyName)}.`;
      }
      return `${formatNaira(result.total)} total expenses${scopeSuffix(periodLabel, propertyName)}.`;
    }
    case 'net': {
      if (!result.income && !result.expenses) {
        return noRecordsMessage({ type: 'records', periodLabel, propertyName });
      }
      return [
        `${formatNaira(result.net)} net${scopeSuffix(periodLabel, propertyName)}.`,
        `Income: ${formatNaira(result.income)}`,
        `Expenses: ${formatNaira(result.expenses)}`,
      ].join('\n');
    }
    case 'expenses_by_category': {
      if (!result.rows?.length) {
        return noRecordsMessage({
          type: 'expenses',
          periodLabel,
          propertyName,
          category,
        });
      }
      if (category && result.rows.length === 1) {
        return `${formatNaira(result.rows[0].total)} on ${result.rows[0].category}${scopeSuffix(periodLabel, propertyName)}.`;
      }
      const lines = [`Expenses by category${scopeSuffix(periodLabel, propertyName)}:`];
      for (const row of result.rows) {
        lines.push(`${row.category}: ${formatNaira(row.total)}`);
      }
      return lines.join('\n');
    }
    case 'last_transactions': {
      if (!result.rows?.length) {
        return noRecordsMessage({ type: 'transactions', periodLabel, propertyName });
      }
      const lines = [`Last ${result.rows.length} transactions:`];
      for (const row of result.rows) {
        const prop = row.property?.name || 'Unknown';
        const label = row.type === 'income' ? 'Income' : row.category || 'Expense';
        lines.push(
          `${formatNaira(row.amount)} • ${label} • ${prop} • ${formatDate(row.transactionDate)}`,
        );
      }
      return lines.join('\n');
    }
    case 'property_summary': {
      if (!result.income && !result.expenses) {
        return noRecordsMessage({
          type: 'records',
          periodLabel,
          propertyName: propertyName || 'that property',
        });
      }
      return [
        propertyName || 'Property',
        '',
        `Income:`,
        formatNaira(result.income),
        '',
        `Expenses:`,
        formatNaira(result.expenses),
        '',
        `Net:`,
        formatNaira(result.net),
      ].join('\n');
    }
    case 'biggest_expense': {
      if (!result.entry) {
        return noRecordsMessage({ type: 'expenses', periodLabel, propertyName });
      }
      const entry = result.entry;
      const prop = entry.property?.name || propertyName || 'Unknown';
      return [
        `Biggest expense${scopeSuffix(periodLabel, propertyName)}:`,
        `${formatNaira(entry.amount)} • ${entry.category || 'expense'} • ${prop}`,
      ].join('\n');
    }
    default:
      return 'No records found.';
  }
}

export function formatUnmatchedProperty(name) {
  return `No records found for ${name}.`;
}

export function formatUnknownQuery() {
  return 'I could not understand that question. Try asking about income, expenses, net, or last transactions.';
}

function noRecordsMessage({ type, periodLabel, propertyName, category }) {
  if (propertyName && type === 'records') {
    return `No records found for ${propertyName}.`;
  }
  if (category) {
    if (periodLabel && periodLabel !== 'all time') {
      return `No ${category} expenses found ${periodLabel}.`;
    }
    return `No ${category} expenses found.`;
  }
  if (type === 'income') {
    if (propertyName) {
      return periodLabel !== 'all time'
        ? `No income found for ${propertyName} ${periodLabel}.`
        : `No income found for ${propertyName}.`;
    }
    return periodLabel !== 'all time'
      ? `No income found ${periodLabel}.`
      : 'No income found.';
  }
  if (type === 'expense' || type === 'expenses') {
    if (propertyName) {
      return periodLabel !== 'all time'
        ? `No expenses found for ${propertyName} ${periodLabel}.`
        : `No expenses found for ${propertyName}.`;
    }
    return periodLabel !== 'all time'
      ? `No expenses found ${periodLabel}.`
      : 'No expenses found.';
  }
  if (type === 'transactions') {
    return periodLabel !== 'all time'
      ? `No transactions found ${periodLabel}.`
      : 'No transactions found.';
  }
  if (propertyName) {
    return `No records found for ${propertyName}.`;
  }
  return periodLabel !== 'all time' ? `No records found ${periodLabel}.` : 'No records found.';
}

function scopeSuffix(periodLabel, propertyName) {
  const parts = [];
  if (propertyName) parts.push(`for ${propertyName}`);
  if (periodLabel && periodLabel !== 'all time') parts.push(periodLabel);
  return parts.length ? ` ${parts.join(' ')}` : '';
}

function formatNaira(amount) {
  const value = Number(amount) || 0;
  return `₦${value.toLocaleString('en-NG')}`;
}

function formatDate(value) {
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  return new Intl.DateTimeFormat('en-GB', {
    timeZone: 'Africa/Lagos',
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  }).format(date);
}

export default {
  formatQueryResult,
  formatUnmatchedProperty,
  formatUnknownQuery,
};
