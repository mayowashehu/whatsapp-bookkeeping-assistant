import { formatLagosMonthYear } from '../utils/dateFormatter.js';
import { deleteTempPdfFile } from '../pdf/tempPdf.js';
import { deliverStatementPdf } from '../whatsapp/delivery/deliverStatementPdf.js';
import { createStatementManager } from './StatementManager.js';
import { interpretStatementRequest } from './StatementRequestInterpreter.js';

/**
 * Orchestrates STATEMENT_REQUEST end-to-end:
 * interpret → generate → deliver → confirm.
 * Reuses StatementManager + deliverStatementPdf.
 * Temporary PDFs are always deleted (delivery finally, or local catch if delivery never runs).
 */
export function createStatementRequestService(deps = {}) {
  const statementManager = deps.statementManager || createStatementManager();
  const deliverPdf = deps.deliverPdf || deliverStatementPdf;
  const interpret = deps.interpret || interpretStatementRequest;
  const deletePdf = deps.deletePdf || deleteTempPdfFile;

  /**
   * @param {{
   *   text: string,
   *   phoneNumber: string,
   *   knownProperties: Array,
   *   referenceDate?: Date
   * }} input
   * @returns {Promise<{ replyText: string, status: string }>}
   */
  async function handleStatementRequest(input) {
    const interpretation = interpret(input.text, {
      knownProperties: input.knownProperties || [],
      referenceDate: input.referenceDate || new Date(),
    });

    if (interpretation.clarificationQuestion) {
      return {
        replyText: interpretation.clarificationQuestion,
        status: 'clarification',
      };
    }

    if (!interpretation.property?.id) {
      return {
        replyText: 'I could not find that property. Please use one of your known property names.',
        status: 'property_not_found',
      };
    }

    const { property, month, year } = interpretation;
    const periodLabel = formatLagosMonthYear(year, month);

    let pdfPath = null;

    try {
      const generated = await statementManager.generateMonthlyStatement({
        propertyId: property.id,
        year,
        month,
      });
      pdfPath = generated.pdfPath;

      const filename = `${slugify(property.name)}-${year}-${String(month).padStart(2, '0')}.pdf`;

      const delivery = await deliverPdf({
        phoneNumber: input.phoneNumber,
        pdfPath,
        filename,
        caption: `${property.name} — ${periodLabel}`,
      });

      // deliverStatementPdf deletes the temp PDF in finally; clear local handle.
      pdfPath = null;

      if (!delivery.success) {
        return {
          replyText:
            'I generated the statement but could not send the PDF. Please try again in a moment.',
          status: 'delivery_failed',
        };
      }

      return {
        replyText: `Your ${periodLabel} statement has been generated and sent.`,
        status: 'sent',
        statementSummary: generated.statementSummary,
      };
    } catch (err) {
      if (pdfPath) {
        await deletePdf(pdfPath);
        pdfPath = null;
      }

      const message = err instanceof Error ? err.message : String(err);
      if (/property not found/i.test(message)) {
        return {
          replyText: `I could not find the property "${property.name}". Please check the name and try again.`,
          status: 'property_not_found',
        };
      }
      throw err;
    }
  }

  return {
    handleStatementRequest,
  };
}

function slugify(value) {
  return String(value || 'property')
    .trim()
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .slice(0, 60) || 'property';
}

const defaultService = createStatementRequestService();

export const handleStatementRequest = defaultService.handleStatementRequest;

export default {
  createStatementRequestService,
  handleStatementRequest,
};
