import {
  MONTHS,
  getLagosDateString,
  resolveProperty,
} from '../ai/parsing/TransactionNormalizer.js';

/**
 * Extracts property / month / year for a STATEMENT_REQUEST.
 * Reuses existing property matching and month name tables — no duplicated parsers.
 *
 * @returns {{
 *   property: { id: string, name: string }|null,
 *   propertyStatus: 'matched'|'none'|'ambiguous'|'missing',
 *   propertyCandidates: Array<{ id: string, name: string }>,
 *   unmatchedProperty: string|null,
 *   month: number|null,
 *   year: number|null,
 *   missingFields: string[],
 *   clarificationQuestion: string|null
 * }}
 */
export function interpretStatementRequest(text, { knownProperties = [], referenceDate = new Date() } = {}) {
  const trimmed = typeof text === 'string' ? text.trim() : '';
  const lower = trimmed.toLowerCase().replace(/\s+/g, ' ');

  const propertyResult = detectProperty(lower, knownProperties);
  const { month, year } = detectMonthYear(lower, referenceDate);

  const missingFields = [];
  if (propertyResult.status === 'missing' || propertyResult.status === 'none') {
    missingFields.push('property');
  }
  if (propertyResult.status === 'ambiguous') {
    missingFields.push('property');
  }
  if (!month) {
    missingFields.push('month');
  }
  if (!year) {
    missingFields.push('year');
  }

  return {
    property: propertyResult.property,
    propertyStatus: propertyResult.status,
    propertyCandidates: propertyResult.candidates,
    unmatchedProperty: propertyResult.unmatchedProperty,
    month,
    year,
    missingFields: [...new Set(missingFields)],
    clarificationQuestion: buildClarificationQuestion({
      missingFields: [...new Set(missingFields)],
      propertyStatus: propertyResult.status,
      propertyCandidates: propertyResult.candidates,
      unmatchedProperty: propertyResult.unmatchedProperty,
    }),
  };
}

function detectProperty(lower, knownProperties) {
  // Prefer longest known label contained in the message (same approach as query interpreter).
  let best = null;
  for (const property of knownProperties || []) {
    const labels = [property.name, ...(property.aliases || [])];
    for (const label of labels) {
      const needle = String(label || '')
        .toLowerCase()
        .trim();
      if (!needle || !lower.includes(needle)) {
        continue;
      }
      if (!best || needle.length > best.len) {
        best = { id: String(property.id), name: property.name, len: needle.length };
      }
    }
  }

  if (best) {
    return {
      property: { id: best.id, name: best.name },
      status: 'matched',
      candidates: [],
      unmatchedProperty: null,
    };
  }

  // If message mentions "apartment"/"apt"/"property" but nothing matched, try resolveProperty on a snippet.
  const mention = extractPropertyMention(lower);
  if (mention) {
    const resolved = resolveProperty(mention, knownProperties);
    if (resolved.status === 'matched') {
      return {
        property: resolved.property,
        status: 'matched',
        candidates: [],
        unmatchedProperty: null,
      };
    }
    if (resolved.status === 'ambiguous') {
      return {
        property: null,
        status: 'ambiguous',
        candidates: resolved.candidates,
        unmatchedProperty: mention,
      };
    }
    return {
      property: null,
      status: 'none',
      candidates: [],
      unmatchedProperty: mention,
    };
  }

  return {
    property: null,
    status: 'missing',
    candidates: [],
    unmatchedProperty: null,
  };
}

function extractPropertyMention(lower) {
  const match =
    /\b((?:apartment|apt|property)\s+[a-z0-9]+)\b/i.exec(lower) ||
    /\bfor\s+([a-z0-9][a-z0-9\s]{0,40}?)\s+(?:statement|report|pdf|month)\b/i.exec(lower);
  return match ? match[1].trim() : null;
}

function detectMonthYear(lower, referenceDate) {
  let month = null;
  let year = null;

  if (/\bthis month\b/.test(lower) || /\bcurrent month\b/.test(lower)) {
    const today = getLagosDateString(referenceDate);
    year = Number(today.slice(0, 4));
    month = Number(today.slice(5, 7));
    return { month, year };
  }

  const yearMatch = /\b(20\d{2})\b/.exec(lower);
  if (yearMatch) {
    year = Number(yearMatch[1]);
  }

  for (const [token, value] of Object.entries(MONTHS)) {
    const re = new RegExp(`\\b${token}\\b`, 'i');
    if (re.test(lower)) {
      month = value;
      break;
    }
  }

  // Numeric month: "month 7" / "07/2026" / "2026-07"
  if (!month) {
    const iso = /\b(20\d{2})[-/](0?[1-9]|1[0-2])\b/.exec(lower);
    if (iso) {
      year = Number(iso[1]);
      month = Number(iso[2]);
    }
  }

  if (!month) {
    const numbered = /\bmonth\s+(0?[1-9]|1[0-2])\b/.exec(lower);
    if (numbered) {
      month = Number(numbered[1]);
    }
  }

  return { month, year };
}

function buildClarificationQuestion({
  missingFields,
  propertyStatus,
  propertyCandidates,
  unmatchedProperty,
}) {
  if (propertyStatus === 'ambiguous' && propertyCandidates?.length > 1) {
    const names = propertyCandidates.map((p) => p.name).join(' or ');
    return `Which property should I use for the statement: ${names}?`;
  }

  if (propertyStatus === 'none' && unmatchedProperty) {
    return `I could not find a property matching "${unmatchedProperty}". Which property should I use?`;
  }

  if (missingFields.includes('property') && missingFields.includes('month')) {
    return 'Which property and which month/year should I use for the statement?';
  }

  if (missingFields.includes('property')) {
    return 'Which property should I generate the statement for?';
  }

  if (missingFields.includes('month') && missingFields.includes('year')) {
    return 'Which month and year should the statement cover?';
  }

  if (missingFields.includes('month')) {
    return 'Which month should the statement cover?';
  }

  if (missingFields.includes('year')) {
    return 'Which year should the statement cover?';
  }

  return null;
}

export default {
  interpretStatementRequest,
};
