import mongoose from 'mongoose';
import Entry from '../models/Entry.js';
import Property from '../models/Property.js';

/**
 * Read-only MongoDB access for statement generation.
 * Confirmed entries only. No calculations. No formatting.
 */
export async function findPropertyById(propertyId) {
  if (!propertyId) {
    return null;
  }
  return Property.findById(propertyId).lean();
}

/**
 * @param {{ propertyId: string, startDate: Date, endDate: Date }} params
 * @returns {Promise<object[]>} Transactions sorted by transactionDate ascending
 */
export async function findConfirmedEntriesForPeriod({ propertyId, startDate, endDate }) {
  return Entry.find({
    status: 'confirmed',
    property: new mongoose.Types.ObjectId(String(propertyId)),
    transactionDate: {
      $gte: startDate,
      $lte: endDate,
    },
  })
    .sort({ transactionDate: 1, createdAt: 1 })
    .lean();
}

export default {
  findPropertyById,
  findConfirmedEntriesForPeriod,
};
