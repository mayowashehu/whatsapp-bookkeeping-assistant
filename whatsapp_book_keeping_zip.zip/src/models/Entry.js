import mongoose from 'mongoose';

export const ENTRY_TYPES = Object.freeze(['income', 'expense']);
export const ENTRY_STATUSES = Object.freeze(['confirmed', 'undone', 'deleted']);

function categoryRequiredForExpense() {
  if (this.type === 'expense') {
    return typeof this.category === 'string' && this.category.trim().length > 0;
  }
  // Income: category must be null/undefined (optional).
  return this.category === null || this.category === undefined;
}

/**
 * Entry — a confirmed bookkeeping record.
 *
 * Only created after explicit user confirmation (never auto-saved).
 * status supports later undo/delete without hard-removing history.
 * category is required for expenses and null for income.
 */
const entrySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: {
        values: ENTRY_TYPES,
        message: 'type must be income or expense',
      },
      required: [true, 'Entry type is required'],
    },

    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Property',
      required: [true, 'Property is required'],
    },

    amount: {
      type: Number,
      required: [true, 'Amount is required'],
      min: [0.01, 'Amount must be greater than zero'],
    },

    // Required for expenses; null for income (domain-accurate, no placeholder labels).
    category: {
      type: String,
      default: null,
      trim: true,
      maxlength: [80, 'Category cannot exceed 80 characters'],
      validate: {
        validator: categoryRequiredForExpense,
        message: 'category is required for expenses and must be null for income',
      },
    },

    description: {
      type: String,
      trim: true,
      default: '',
      maxlength: [500, 'Description cannot exceed 500 characters'],
    },

    sourceText: {
      type: String,
      required: [true, 'sourceText is required'],
      trim: true,
      maxlength: [4000, 'sourceText cannot exceed 4000 characters'],
    },

    transactionDate: {
      type: Date,
      required: [true, 'transactionDate is required'],
    },

    confirmedAt: {
      type: Date,
      required: [true, 'confirmedAt is required'],
    },

    status: {
      type: String,
      enum: {
        values: ENTRY_STATUSES,
        message: 'status must be confirmed, undone, or deleted',
      },
      required: [true, 'status is required'],
      default: 'confirmed',
    },
  },
  {
    timestamps: true,
  },
);

entrySchema.index({ property: 1, transactionDate: -1 });
entrySchema.index({ status: 1, transactionDate: -1 });
entrySchema.index({ createdAt: -1 });
entrySchema.index({ category: 1, status: 1, transactionDate: -1 });

const Entry = mongoose.model('Entry', entrySchema);

export default Entry;
