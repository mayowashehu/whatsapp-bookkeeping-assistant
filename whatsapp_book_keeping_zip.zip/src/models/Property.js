import mongoose from 'mongoose';

/**
 * Property — a known rental unit managed by the pilot user.
 *
 * Kept intentionally small for v0.1 (known list, one user).
 * aliases allow natural-language matching ("Apt 2", "Apartment 2")
 * without schema changes when the user phrases names differently.
 */
const propertySchema = new mongoose.Schema(
  {
    // Display / canonical name used in replies and PDF statements.
    name: {
      type: String,
      required: [true, 'Property name is required'],
      trim: true,
      unique: true,
      maxlength: [120, 'Property name cannot exceed 120 characters'],
    },

    // Alternate names the user may say in WhatsApp messages.
    aliases: {
      type: [
        {
          type: String,
          trim: true,
          maxlength: [120, 'Alias cannot exceed 120 characters'],
        },
      ],
      default: [],
    },

    // Soft flag so a property can be retired without deleting history.
    active: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  },
);

// Speeds up alias lookups during message parsing.
propertySchema.index({ aliases: 1 });
propertySchema.index({ active: 1 });

const Property = mongoose.model('Property', propertySchema);

export default Property;
