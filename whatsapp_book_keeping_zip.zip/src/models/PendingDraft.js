import mongoose from 'mongoose';
import { ENTRY_TYPES } from './Entry.js';

/**
 * Validation:
 * Category is only required once the draft type is expense.
 */
function categoryRequiredForExpense() {
  if (this.type !== 'expense') {
    return this.category === null || this.category === undefined;
  }

  // If expense is still incomplete we don't validate yet.
  if (!this.type) {
    return true;
  }

  return typeof this.category === 'string' && this.category.trim().length > 0;
}

/**
 * Partial draft.
 *
 * Unlike Entry, almost every field is optional because
 * clarification happens over multiple WhatsApp messages.
 */
const draftEntrySchema = new mongoose.Schema(
  {
    type: {
      type: String,
      enum: ENTRY_TYPES,
      default: null,
    },

    property: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Property',
      default: null,
    },

    amount: {
      type: Number,
      default: null,
      min: 0.01,
    },

    category: {
      type: String,
      default: null,
      trim: true,
      maxlength: 80,
      validate: {
        validator: categoryRequiredForExpense,
        message:
          'category is required for expenses and must be null for income',
      },
    },

    description: {
      type: String,
      default: '',
      trim: true,
      maxlength: 500,
    },

    sourceText: {
      type: String,
      default: '',
      trim: true,
      maxlength: 4000,
    },

    transactionDate: {
      type: Date,
      default: null,
    },
  },
  {
    _id: false,
  },
);

/**
 * Tracks clarification progress.
 */
const clarificationSchema = new mongoose.Schema(
  {
    awaiting: {
      type: Boolean,
      default: false,
    },

    missingFields: {
      type: [String],
      default: [],
    },

    question: {
      type: String,
      default: '',
      trim: true,
    },
  },
  {
    _id: false,
  },
);

/**
 * One pending draft per WhatsApp sender.
 */
const pendingDraftSchema = new mongoose.Schema(
  {
    fromNumber: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      maxlength: 32,
    },

    draftEntry: {
      type: draftEntrySchema,
      required: true,
    },

    clarification: {
      type: clarificationSchema,
      default: () => ({
        awaiting: false,
        missingFields: [],
        question: '',
      }),
    },
  },
  {
    timestamps: true,
  },
);

const PendingDraft = mongoose.model(
  'PendingDraft',
  pendingDraftSchema,
);

export default PendingDraft;