import { verifyWebhookChallenge } from '../whatsapp/services/webhookVerification.service.js';
import { receiveWebhook } from '../whatsapp/services/webhookReceive.service.js';

/**
 * Thin WhatsApp webhook controller — HTTP only; logic lives in services.
 */
export function verifyWebhook(req, res, next) {
  try {
    const challenge = verifyWebhookChallenge({
      mode: req.query['hub.mode'],
      token: req.query['hub.verify_token'],
      challenge: req.query['hub.challenge'],
    });

    res.status(200).send(challenge);
  } catch (err) {
    next(err);
  }
}

export function receiveWebhookMessage(req, res, next) {
  try {
    receiveWebhook(req.body);
    // Always acknowledge quickly after validation + async dispatch.
    res.status(200).send('EVENT_RECEIVED');
  } catch (err) {
    next(err);
  }
}
